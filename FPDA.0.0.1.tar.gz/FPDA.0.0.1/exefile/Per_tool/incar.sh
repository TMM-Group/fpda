#!/bin/bash
cat >INCAR<<eof
SYSTEM = CRYSTAL

KSPACING = 0.2

PREC = Normal
LREAL = .FALSE.

IBRION = 1     #(1-quasi-Newton;2-CG;0-MD)    
ISIF = 3       

ISMEAR = 0      
SIGMA = 0.1
NSW = 200   

EDIFF = 1E-5
EDIFFG = -1E-2
ENCUT = 650  # 500*1.3

LWAVE = .FALSE.
LCHARG = .FALSE.

NPAR = 6
NSIM = 4
LPLANE = .TRUE.
#GGA = PS

#POTIM = 0.5
#NELM = 80 
#NELMIN = 2         
eof
#echo " "
#echo '*********************************'
#echo -e "\e[1;33m  Please check the INCAR file \e[0m" 
#echo '*********************************'
#echo " "

##
echo " +---------------------------------------------------------------+ "
echo -e " \e[1;32m[SUCCESS]\e[0m INCAR file was written! "
