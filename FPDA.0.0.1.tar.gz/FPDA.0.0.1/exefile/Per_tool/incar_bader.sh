#!/bin/bash
if [ -s INCAR ]; then
cat >incar_dos<<eof
#tvasp
LAECHG = .TRUE.
#tvasp
eof
sed -i '2r incar_dos' INCAR #INCAR 文件不存在第二行则不能正常写入但是会提示成功。
rm -f incar_dos
echo " +===============================-===============================+"
echo -e " \e[1;32m[SUCCESS]\e[0m Please check the INCAR file and modify PREC. " 

else
echo " +===============================-===============================+"
echo -e " \e[1;31m[ERROR]\e[0m INCAR file not exist!"
echo "         A basic INCAR file is needed for writing key INCAR tags."
fi
