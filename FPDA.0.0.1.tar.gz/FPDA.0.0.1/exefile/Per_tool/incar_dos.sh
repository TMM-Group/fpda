#!/bin/bash
if [ -s INCAR ]; then
cat >incar_dos<<eof
#tvasp
ICHARG = 11  #(0:iniwave;1:CHGCAR;2:atom;11:band calc.) 
LORBIT = 11

EMAX = 8 
EMIN = -20  
NEDOS = 2801                                            
#tvasp
eof
sed -i '2r incar_dos' INCAR
rm -f incar_dos
#echo '*********************************************************'
#echo " +---------------------------------------------------------------+"
echo " +===============================-===============================+"
echo -e " \e[1;32m[SUCCESS]\e[0m Please check the INCAR file and modify ISMEAR, etc." 
#echo -e "\e[1;33m and modify ISMEAR and so on \e[0m"

else
#echo " +---------------------------------------------------------------+"
echo " +===============================-===============================+"
echo -e " \e[1;31m[ERROR]\e[0m The INCAR file not exist!" 
echo "         A basic INCAR file is needed for writing key INCAR tags."
fi
