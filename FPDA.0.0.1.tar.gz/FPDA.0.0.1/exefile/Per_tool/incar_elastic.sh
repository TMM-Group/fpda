#!/bin/bash
if [ -s INCAR ]; then
cat >incar_dos<<eof
#tvasp
IBRION = 6
NFREE = 2  
#tvasp
eof
sed -i '2r incar_dos' INCAR
rm -f incar_dos
#echo '**************************************************************'
#echo " +---------------------------------------------------------------+"
echo " +===============================-===============================+"
echo -e " \e[1;32m[SUCCESS]\e[0m Please check the INCAR file and modify ENCUT, ISIF, etc." 
#echo -e "\e[1;33m and modify ENCUT ISIF and so on \e[0m"
#echo '**************************************************************'
else
echo " +===============================-===============================+"
#echo " +---------------------------------------------------------------+"
echo -e " \e[1;31m[ERROR]\e[0m The INCAR file not exist!" 
echo "         A basic INCAR file is needed for writing key INCAR tags."
fi
