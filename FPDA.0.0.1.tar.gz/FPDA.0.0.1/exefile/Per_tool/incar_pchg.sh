#!/bin/bash
if [ -s INCAR ]; then
cat >incar_dos<<eof
#tvasp
LPARD = .TRUE.  #partial charge density calculation 
IBAND = 121
#NBMOD = 1
KPUSE = 1
LSEPB = .TRUE.
LSEPK = .TRUE.
ICHARG = 1
NELM = 200                                          
#tvasp
eof
sed -i '2r incar_dos' INCAR
rm -f incar_dos
#echo '*******************************************************'
#echo " +---------------------------------------------------------------+"
echo " +===============================-===============================+"
echo -e " \e[1;32m[SUCCESS]\e[0m Please check the INCAR file and modify PREC, etc." 
#echo -e "\e[1;33m and modify PREC and so on \e[0m"
#echo '*******************************************************'

else
#echo " +---------------------------------------------------------------+"
echo " +===============================-===============================+"
echo -e " \e[1;31m[ERROR]\e[0m The INCAR file not exist!" 
echo "         A basic INCAR file is needed for writing key INCAR tags."
fi
