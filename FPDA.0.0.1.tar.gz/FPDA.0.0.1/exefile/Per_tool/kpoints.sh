#!/bin/bash
#read -p "请输入参数（以空格分隔）：" args

# 使用正则表达式进行参数检查
echo " +===============================-===============================+"
echo " 1)  Generate a KPOINTS file in the standard format"
echo -e " Or) Enter 'G/M num num num' to Generate a KPOINTS file\n 0)  Quit"
echo  " ************^-^*************"
echo -n "➤"
read -a args  # 将用户输入的参数存储到数组args中

# 使用正则表达式进行参数检查
if [ "${#args[@]}" = 1 ] && [ "${args[0]}" = 0 ]; then
    exit
#elif [ -z "${args[*]}" ]; then
elif [ "${#args[@]}" = 1 ] && [ "${args[0]}" = 1 ]; then
    :
elif [[ ${args[*]} =~ ^[GM]( [1-9][0-9]*){3}$ ]]; then
    :
else
    echo -e " \e[1;31m[ERROR]\e[0m Your input is WRONG！ TRY 'G 1 1 1'"
    exit
fi
#echo "${args[1]} ${args[2]} ${args[3]}"

echo K-POINTS > KPOINTS
echo " 0" >> KPOINTS

#if [ -z "$args" ]; then
if [ "${#args[@]}" = 1 ] && [ "${args[0]}" = 1 ]; then
    echo Gamma-Centered >> KPOINTS
    echo " 1 1 1" >> KPOINTS
    echo " 0 0 0" >> KPOINTS
    echo  " +===============================-===============================+"
    echo -e " \e[1;32m[SUCCESS]\e[0m KPOINTS file was written! "
    exit
else
    if [ "${args:0:1}" == "M" ]; then
        echo Monkhorst-Pack >> KPOINTS
    elif [ "${args:0:1}" == "G" ]; then
        echo Gamma-Centered >> KPOINTS
    fi
    echo " ${args[1]} ${args[2]} ${args[3]}" >> KPOINTS
    echo " 0 0 0" >> KPOINTS
    echo  " +===============================-===============================+"
    echo -e " \e[1;32m[SUCCESS]\e[0m KPOINTS file was written! "
fi

