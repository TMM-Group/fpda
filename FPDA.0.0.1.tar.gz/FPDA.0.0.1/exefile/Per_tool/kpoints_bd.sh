#!/bin/bash

cat >KPOINTS<<eof
GAPbI3  pna21 33 G-Y-T-Z-G-X-U-R-T
40
l
r
0.0 0.0 0.0
0.0 0.5 0.0      
eof
#echo '*******************************'
echo  " +===============================-===============================+"
echo -e " \e[1;32m[SUCCESS]\e[0m KPOINTS file was written! "
#echo '*******************************'
