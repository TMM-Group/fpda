#!/bin/bash -e

myPWD=$(pwd)
search_directory="/thfs1/home/tanggang/pseudopotential"
###  +=====居中打印文字=====+

function print_center() {       #不支持中文
  local text=$1
  local line_width=65

  local text_length=${#text}

  # 判断文本长度是否为零
  if [ "$text_length" -eq 0 ]; then
    echo  " +===============================-===============================+"
  else
    # 计算填充的等号数
    local left_fill_count=$(((line_width - text_length - 2 - 2) / 2))
    local right_fill_count=$((line_width - text_length - left_fill_count - 2 - 2))
    equals1=$(printf '=%.0s' $(seq 1 "$left_fill_count"))
    equals2=$(printf '=%.0s' $(seq 1 "$right_fill_count"))
    echo " +$equals1 $text $equals2+"
  fi
}
#-------------------------------------
print_center "Option"
printf " 1) Generating the pseudopotential using the default settings. \n"
printf " 2) Generating the pseudopotential according to the user's input. \n"
printf " 3) Generating the pseudopotential according to the user's choice. \n"
echo ""
echo " Please input your choice "
echo " 0) Quit"
echo  " ************^-^*************"
echo -n "➤"
read  choice #read命令读取用户输入默认是字符串
choice=$((choice)) #通过$(( ))或(( ))将其转换为数值类型
if ! [[ "$choice" =~ ^[0-3]$ ]]; then
      echo -e " \e[1;31m[ERROR]\e[0m Invalid input"
	  exit 1
fi
# 获取用户的选择
if [ "$choice" -eq 0 ]; then
    exit
elif [ "$choice" -eq 1 ]; then
             # 检查POSCAR文件是否存在
            if [[ -f "POSCAR" ]]; then
                # 检查POTCAR文件是否存在
                if [[ -f "POTCAR" ]]; then
                    # 备份已存在的POTCAR文件
                    mv "POTCAR" "POTCAR.bak"
                fi
                
                # 读取POSCAR文件的第6行
                line=$(sed -n '6p' POSCAR | tr -d '\r')
                
                # 将第6行按空格分隔成数组  
                read -ra array <<< "$line"  
                
                # 定义目录路径和保存结果的数组
                matching_folders=()
                selected_folders=()
                
                # 遍历数组中的元素
                for element in "${array[@]}"; do
                    # 清空匹配文件夹列表
                    matching_folders=()
                
                    # 检查元素是否为H
                    if [[ "${element}" == "H" ]]; then
                        # 检查是否存在H文件夹
                        if [[ -d "$search_directory/H" ]]; then
                            matching_folders+=("H")
                        fi
                
                        # 查找以H.或H_开头的文件夹
                        matching_folders+=($(find "$search_directory" -maxdepth 1 -type d -name "H.*" -o -name "H_*" | awk -F/ '{print $NF}'))
                
                    else
                        # 检查是否存在以 $element 开头的文件夹
                        if [[ -d "$search_directory/${element}" ]]; then
                            matching_folders+=("${element}")
                        fi
                
                        # 查找以 $element_ 开头的文件夹
                        matching_folders+=($(find "$search_directory" -maxdepth 1 -type d -name "${element}_*" | awk -F/ '{print $NF}'))
                    fi
              
                    if [[ "${matching_folders[0]}" != *GW ]]; then
                       cat "$search_directory/${matching_folders[0]}/POTCAR" >> "$myPWD/POTCAR"
                    else
                       cat "$search_directory/${matching_folders[1]}/POTCAR" >> "$myPWD/POTCAR"
                    fi
                    
                done
                
                # 打印最终选择的字符串数组
                selected_folders+=($(awk '/TIT/{gsub(/  +/, " "); sub(/^ */, ""); printf "%s ", $4}' POTCAR))
				echo -e " \e[1;32m[SUCCESS]\e[0m POTCAR file was written! "
                printf "          \033[36m The pseudopotential you chose is：%s\033[0m\n" "$(IFS=" "; echo "${selected_folders[*]}")"

            else
                printf "\033[31m [ERROR] The POSCAR file does not exist. \033[0m\n"
            fi

            exit 0
elif [ "$choice" -eq 2 ]; then
            # 获取除第一个参数以外的所有参数
			echo " Enter the name of the pseudopotential in order,such as 'Cs_sv Pb I'."
			read -a params  # 将用户输入的参数存储到数组params中
            
            # 检查数组是否为空
            if [[ ${#params[@]} -eq 0 ]]; then
                printf "\033[31m [ERROR] Please provide the name of the pseudopotential you want to generate.\033[0m\n"
                exit 1
            fi
            
            # 将参数数组赋值给 "array"
            array=("${params[@]}") 
            
            # 定义目录路径和保存结果的数组
            matching_folders=()
            selected_folders=()
            
            if [[ -f "POTCAR" ]]; then
                 # 备份已存在的POTCAR文件
                 mv "POTCAR" "POTCAR.bak"
            fi
            
            # 遍历数组中的元素
            for element in "${array[@]}"; do
            
                 # 检查是否存在以 $element 开头的文件夹
                 if [[ -d "$search_directory/${element}" ]]; then
                     cat "$search_directory/${element}/POTCAR" >> "$myPWD/POTCAR" 
                     has_potcar=true
                 else 
                     printf "\033[31m [ERROR] The pseudopotential of %s does not exist.\033[0m\n"  "$element"
                     has_potcar=false  # 标记为不存在赝势
                     rm -rf POTCAR
                     break
                 fi
            done

            # 根据标志决定是否执行打印操作
            if [[ "$has_potcar" == true ]]; then
                # 打印最终选择的字符串数组
                selected_folders+=($(awk '/TIT/{gsub(/  +/, " "); sub(/^ */, ""); printf "%s ", $4}' POTCAR))
                echo -e "\e[1;32m [SUCCESS]\e[0m POTCAR file was written! "
                printf "          \033[36m The pseudopotential you chose is：%s\033[0m\n" "$(IFS=" "; echo "${selected_folders[*]}")"
            fi
            
            exit 0
elif [ "$choice" -eq 3 ]; then
            # 检查POSCAR文件是否存在
            if [[ -f "POSCAR" ]]; then
                # 检查POTCAR文件是否存在
                if [[ -f "POTCAR" ]]; then
                    # 备份已存在的POTCAR文件
                    mv "POTCAR" "POTCAR.bak"
                fi
                
                # 读取POSCAR文件的第6行
                line=$(sed -n '6p' POSCAR | tr -d '\r')
                
                # 将第6行按空格分隔成数组  
                read -ra array <<< "$line"  
                
                # 定义目录路径和保存结果的数组
                matching_folders=()
                selected_folders=()
                
                # 遍历数组中的元素
                for element in "${array[@]}"; do
                    # 清空匹配文件夹列表
                    matching_folders=()
                
                    # 检查元素是否为H
                    if [[ "${element}" == "H" ]]; then
                        # 检查是否存在H文件夹
                        if [[ -d "$search_directory/H" ]]; then
                            matching_folders+=("H")
                        fi
                
                        # 查找以H.或H_开头的文件夹
                        matching_folders+=($(find "$search_directory" -maxdepth 1 -type d -name "H.*" -o -name "H_*" | awk -F/ '{print $NF}'))
                
                    else
                        # 检查是否存在以 $element 开头的文件夹
                        if [[ -d "$search_directory/${element}" ]]; then
                            matching_folders+=("${element}")
                        fi
                
                        # 查找以 $element_ 开头的文件夹
                        matching_folders+=($(find "$search_directory" -maxdepth 1 -type d -name "${element}_*" | awk -F/ '{print $NF}'))
                    fi
                
                    # 将当前元素的所有匹配文件夹合并为一行，用单空格替换多个连续的空格
                    folders_line=$(IFS="  "; echo "${matching_folders[*]}")
                
                    # 打印当前元素的匹配文件夹结果
                    printf " $folders_line\n"
                
                    # 初始化用户选择的字符串
                    selected_folder=""
                
                    # 循环提示用户输入，直到输入一个有效的字符串
                    while [[ -z "$selected_folder" ]]; do
                        # 读取用户选择的字符串，禁用特殊字符的转义
                        read -r -e -p " Please choose a pseudopotential type： " selected_folder
                
                        # 检查选择的字符串是否在匹配文件夹列表中
                        found=false
                        for folder in "${matching_folders[@]}"; do
                            if [[ "$selected_folder" == "$folder" ]]; then
                                found=true
                                break
                            fi
                        done
                
                        if [[ "$found" == false ]]; then
                            printf "\033[31m Input error, please re-enter. \033[0m\n" 
                            selected_folder=""
                        fi
                    done
                
                    # 将选择的字符串保存到数组中
                    selected_folders+=("$selected_folder")
                    cat "$search_directory/$selected_folder/POTCAR" >> "$myPWD/POTCAR"
                done
                
                # 打印最终选择的字符串数组
                echo -e "\e[1;32m [SUCCESS]\e[0m POTCAR file was written! "
                printf "          \033[36m The pseudopotential you chose is：%s\033[0m\n" "$(IFS=" "; echo "${selected_folders[*]}")"
            
            else
                printf "\033[31m [ERROR] Please note: The POSCAR file does not exist!\033[0m\n"
            fi
            exit 0
fi

