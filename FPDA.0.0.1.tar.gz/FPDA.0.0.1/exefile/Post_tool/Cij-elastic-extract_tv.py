#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.23

### Usage Commands ###
'''
First Step: put "OUTCAR (including Born effective charge)", "POSCAR.reference" and "POSCAR.polar"files in the same directory,  

Second Step: run the command: python bcpolarization_v2.py POSCAR.reference POSCAR.polar 
'''
import os

files = os.listdir('.') # 当前目录
if 'OUTCAR' not in files:
  print("\033[31m [ERROR]\033[0m OUTCAR file not exist!")
  exit()

idx_map = {
    'XX': 1,
    'YY': 2, 
    'ZZ': 3, 
    'XY': 6,
    'YZ': 4,
    'ZX': 5 
}

with open('OUTCAR', 'r') as f:
    lines = f.readlines()   

# 找到"TOTAL ELASTIC MODULI (kBar)"这一行  
start_index = 0
for i, line in enumerate(lines):
    if 'TOTAL ELASTIC MODULI (kBar)' in line:
        start_index = i + 3
        break
if start_index == 0:
   print("\033[31m [ERROR]:\033[0m\n    Please verify if the OUTCAR file contains ELASTIC MODULI!")
   print("    Or some information of the OUTCAR may be modified!")
   exit()
# 读取弹性常数矩阵        
elastic_constants = []
for line in lines[start_index:start_index+6]:
    elastic_constants.append([float(x) for x in line.split()[1:]])  

# 创建一个空字典存储弹性常数
elastic_dict = {}

for i in range(6):
    for j in range(6):
        # 如果常数不为0,则存储在字典中
        # 但键必须为Cij,i和j对应的是idx_map中的映射         
        if elastic_constants[i][j] != 0:   
            elastic_dict['C{}{}'.format(idx_map[lines[start_index+i].split()[0]],
                                       idx_map[lines[start_index+j].split()[0]])] = elastic_constants[i][j]

# 打印所有非零弹性常数  
#for key in elastic_dict: 
#    print(key, elastic_dict[key])

'''
# 1生成弹性常数键的列表           
keys = [key for key in elastic_dict]

# 打印弹性常数键
print(' '.join(keys))

# 打印对应的值  
print(' '.join([str(elastic_dict[key]) for key in keys]))

# 打印一个空行 
print()  
'''


# 2生成弹性常数键的列表           
keys = [key for key in elastic_dict]

# 找出键和值中最长的字符串,用于后续的对齐
key_len = max(len(key) for key in keys)  
val_len = max(len(str(elastic_dict[key] / 10)) for key in keys) 

'''
# 打印弹性常数键,使用.format()进行对齐
print(' '.join(['{:<{}s}'.format(key, key_len) for key in keys]))

# 打印对应的值,使用.format()进行对齐,但值除以10 
print(' '.join(['{:<{}s}'.format(str(elastic_dict[key] / 10), val_len) for key in keys]))   

# 打印一个空行
print()
'''

'''
# 计算对齐所需的偏移量
offset = max(len(key) - len(str(elastic_dict[key])) for key in keys)

# 打印弹性常数键和对应的值，使用.format()进行对齐
for key in keys:
    value = str(elastic_dict[key]/10)
    print(" "'{:<{}s} {:>{}}'.format(key, key_len, value, val_len + offset))
'''

'''
from tabulate import tabulate

# 将字典的键和值分别转换为列表
keys = list(elastic_dict.keys())
values = list(elastic_dict.values()/10)

# 构建包含键和对应值的列表
table = [keys, values]

# 打印表格
print(tabulate(table, tablefmt="plain"))
'''


# 创建一个6x6的列表来表示矩阵
matrix = [[0 for j in range(6)] for i in range(6)]

# 将elastic_dict中的值填入matrix矩阵中
for key in elastic_dict:
    i = int(key[1])-1
    j = int(key[2])-1
    matrix[i][j] = elastic_dict[key] / 10

# 打印矩阵
print("\033[36m           *** Starting to print elastic tensors Ckj *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(6):
    row = ' '.join('{:^8.4f}'.format(matrix[i][j]) for j in range(6))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")
    
with open('ELASTIC_MODULI', 'w') as file:
    file.write('TOTAL ELASTIC MODULI (GPa)\n')
    # 生成弹性常数键的列表
    keys = [key for key in elastic_dict]
    # 找出键和值中最长的字符串，用于后续的对齐
    key_len = max(len(key) for key in keys)
    # 打印弹性常数键和对应的值，小数点对齐，并保存到文件
    for key in keys:
        value = '{:.4f}'.format(elastic_dict[key] / 10)
        line = ' {:<{}s} {:>11s}'.format(key, key_len, value)
        file.write(line + '\n')
    

    file.write("\n")
    for i in range(6):
        file.write('{:8.4f} {:8.4f} {:8.4f} {:8.4f} {:8.4f} {:8.4f}\n'.format(
            matrix[i][0], matrix[i][1], matrix[i][2],
            matrix[i][3], matrix[i][4], matrix[i][5]))
print("\033[32m [SUCCESS]\033[0m ELASTIC_MODULI file was written.")

