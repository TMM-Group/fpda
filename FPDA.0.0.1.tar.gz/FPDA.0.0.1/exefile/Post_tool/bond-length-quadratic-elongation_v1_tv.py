#!/usr/bin/env python
# -*- coding: utf-8 -*

#Written by Gang Tang-20230526
import os
import re
import spglib
import numpy as np
from ase.io import read
from ase.neighborlist import neighbor_list
from collections import defaultdict
import argparse
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  line_num=(len(line)-len(text)-2-2)//2
  prompt = "=" * line_num
  if len(text) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(text) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-------------------------------------------------------

files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
def input_param():
  print(" +==========================Warm Prompt==========================+")
  print(" | Enter three parameters: inputfile cutoff elements             |")
  print(" | Or use '-' for default values.                                |")
  print(" |   inputfile -- Input file name (default: POSCAR)              |")
  print(" |   cutoff    -- Cutoff radius (default: 3.3)                   |")
  print(" |   elements  -- Element pairs (separated by '-',e.g. A-B)      |")
  print(" |\033[31m Note\033[0m        -- A: octahedron center element, B: vertex element|")
  print(" | Example:                                                      |")
  print(" |  'file 3.5 Fe-O','- - Ti-O','- 1.5 F-Cl','file - Br-I'        |")
  print(" +===============================-===============================+")
      ##-----------------------打印当前文件价文件-------------------------------
  #print(" +===============================-===============================+")
  line_text("Current directory files")
  max_len = 57
  line_len = 0
  i=-1 #计数
  for file in files:
    i+=1
    if i == 0:
      print("  -", end='')  #单独为第一行打印 -
    if line_len + len(file) > max_len:
      print("\n", end='  -')
      line_len = 0  
    print(" "+file, end=', ')
    line_len += len(file) + 2
   #print("\n +===============================-===============================+")
  print("\n", end='')
    #-----------------------------------------------------------------
  ##输入参数
  print(" +===============================-===============================+")
  print(" Enter parameters (separated by space)\n 0) quit")
  print(" ************^-^*************")
  print("➤", end='')
  params = input().split()
  ##
  if params[0] == '0' and len(params) == 1:
    exit()
  if len(params) != 3:
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m Enter three parameters! Please retry.")
    return input_param()
  ##判断文件夹名是否存在
  inputfile = params[0]
  if inputfile == '-':
    inputfile = "POSCAR"
  if not os.path.exists(inputfile):
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m POSCAR file '"+inputfile+"' does not exist! Please retry.")
    return input_param()
  ##判断截断半径是否有效
  cutoff_str = params[1]
  if cutoff_str == '-':
    cutoff = 3.3
  else:
    try:
      cutoff = float(cutoff_str)
      if cutoff <= 0:
        print()
        print(" +===============================-===============================+")
        print("\033[31m [ERROR]\033[0m Cutoff must be greater than 0! Please retry.")
        return input_param()
    except ValueError:
      print()
      print(" +===============================-===============================+")
      print("\033[31m [ERROR]\033[0m Invalid cutoff value!")
      return input_param()
  ##判断输入元素是否有效
  elements = params[2]
  if '-' not in elements or elements == '-':
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m Element pairs '{}' must be separated by '-'! Please retry.".format(elements))
    return input_param()
       ##检查输入元素是否为POSCAR
  atoms = read(inputfile, format='vasp')
  atom_symbols = set(atoms.get_chemical_symbols())
  check_elements = elements.split('-')
  for element in check_elements:
    if element not in atom_symbols:
      print()
      print(" +===============================-===============================+")
      print(f"\033[31m [ERROR]\033[0m {element} not found in POSCAR file '{inputfile}'! Please retry.")
      return input_param()
  return inputfile, cutoff, elements
# Get parameters
inputfile, cutoff, elements = input_param()

def get_nearest_neighbors(poscar, atom_indices, element, cutoff):
    neighbor_list_data = neighbor_list("ijdD", poscar, cutoff, self_interaction=False)
    neighbors = []
    for i in atom_indices:
        indices = neighbor_list_data[1][neighbor_list_data[0] == i]
        symbols = poscar[indices].get_chemical_symbols()
        neighbor_indices = [indices[j] for j, symbol in enumerate(symbols) if symbol == element]
        neighbors.append(neighbor_indices[:6])  # Get the closest 6 neighbors
    return neighbors
'''
# Parse command line arguments
parser = argparse.ArgumentParser(description='Calculate average bond length quadratic elongation (λ) for octahedron')
parser.add_argument('input_file', type=str, help='Input file (POSCAR format)')
parser.add_argument('elements', type=str, help='Elements B and X separated by "-"')
parser.add_argument('cutoff', type=float, help='Cutoff distance for bond lengths')
args = parser.parse_args()
'''
# Read in POSCAR file
poscar = read(inputfile, format="vasp")

# Split elements B and X
elements = elements.split('-')
element_B = elements[0]
element_X = elements[1]

# Specify the atom indices for B and X
indices_B = [i for i, atom in enumerate(poscar) if atom.symbol == element_B]
indices_X = [i for i, atom in enumerate(poscar) if atom.symbol == element_X]

# Get the distances between B and the closest 6 X atoms
bond_lengths = defaultdict(list)
neighbor_indices_X = get_nearest_neighbors(poscar, indices_B, element_X, cutoff)
for i, indices in zip(indices_B, neighbor_indices_X):
    for j in indices:
        distance = poscar.get_distance(i, j, mic=True)
        bond_lengths[i].append(distance)
'''
# Print the distances
for i, distances in bond_lengths.items():
    print("Distances from {}{} to the closest 6 {} atoms:".format(element_B, i, element_X))
    for j, distance in enumerate(distances):
        print("{}{}-{}{} distance: {:.5f} Å".format(element_X, j+1, element_B, i, distance))
'''

# Calculate the average for each distances array (i.e., d0)
averages = [np.mean(distances) for distances in bond_lengths.values()]

# Calculate the squared reciprocal for each element in each distances array (i.e., di/d0)
squared_reciprocals = [[(distance / average) ** 2 for distance in distances] for average, distances in zip(averages, bond_lengths.values())]

# Calculate the sum of squared reciprocals for each distances array and divide by 6 
final_results = [sum(array) / 6 for array in squared_reciprocals]

# Calculate the average of final results
average_final_result = np.mean(final_results)

# Print the final results
print(" +===============================-===============================+")
print("\033[32m [SUCCESS]:\033[0m")
for i, result in zip(indices_B, final_results):
    print("    Bond length distortion for {} octahedron (λ) {}{}: {:.5f}".format(i+1, element_B, i+1, result))

# Print the average of final results
print("    Average values (λ) for {} octahedron: {:.5f}".format(len(indices_B), average_final_result))
#print(" +===============================-===============================+")
'''
print(f"Average values (λ) for {len(indices_B)} octahedron: {average_final_result:.5f}")
'''
