#!/usr/bin/env python
# -*- coding: utf-8 -*

#Written by Gang Tang-20230527
import os
import re
import numpy as np
from ase import Atoms
from ase.io import read
from ase.neighborlist import NeighborList
from itertools import combinations
import argparse

###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  line_num=(len(line)-len(text)-2-2)//2
  prompt = "=" * line_num
  if len(text) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(text) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-------------------------------------------------------

def input_param():
  print(" +==========================Warm Prompt==========================+")
  print(" | Enter three parameters: inputfile cutoff elements             |")
  print(" | Or use '-' for default values.                                |")
  print(" |   inputfile -- Input file name (default: POSCAR)              |")
  print(" |   cutoff    -- Cutoff radius (default: 3.3)                   |")
  print(" |   elements  -- Element pairs (separated by '-',e.g. A-B)      |")
  print(" |\033[31m Note\033[0m        -- A: octahedron center element, B: vertex element|")
  print(" | Example:                                                      |")
  print(" |  'file 3.5 Fe-O','- - Ti-O','- 1.5 F-Cl','file - Br-I'        |")
  print(" +===============================-===============================+")
  
    #--------------读取当前目录文件去除隐藏文件----------------
  files = os.listdir('.') # 当前目录
  files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
    #---------------------------------------------------------------------------

    ##-----------------------打印当前文件价文件-------------------------------
    #print(" +===============================-===============================+")
  line_text("Current directory files")
  max_len = 57
  line_len = 0
  i=-1 #计数
  for file in files:
    i+=1
    if i == 0:
      print("  -", end='')  #单独为第一行打印 -
    if line_len + len(file) > max_len:
      print("\n", end='  -')
      line_len = 0  
    print(" "+file, end=', ')
    line_len += len(file) + 2
  #print("\n +===============================-===============================+")
  print("\n", end='')
  ##输入参数
  print(" +===============================-===============================+")
  print(" Enter parameters (separated by space)\n 0) quit")
  print(" ************^-^*************")
  print("➤", end='')
  params = input().split()
  ##
  if params[0] == '0' and len(params) == 1:
    exit()
  if len(params) != 3:
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m Enter three parameters! Please retry.")
    return input_param()
  ##判断文件夹名是否存在
  inputfile = params[0]
  if inputfile == '-':
    inputfile = "POSCAR"
  if not os.path.exists(inputfile):
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m POSCAR file '"+inputfile+"' not exist! Please retry.")
    return input_param()
  ##判断截断半径是否有效
  cutoff_str = params[1]
  if cutoff_str == '-':
    cutoff = 3.3
  else:
    try:
      cutoff = float(cutoff_str)
      if cutoff <= 0:
        print()
        print(" +===============================-===============================+")
        print("\033[31m [ERROR]\033[0m Cutoff must be greater than 0! Please retry.")
        return input_param()
    except ValueError:
      print()
      print(" +===============================-===============================+")
      print("\033[31m [ERROR]\033[0m Invalid cutoff value!")
      return input_param()
  ##判断输入元素是否有效
  elements = params[2]
  if '-' not in elements or elements == '-':
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m Element pairs '{}' must be separated by '-'! Please retry.".format(elements))
    return input_param()
       ##检查输入元素是否为POSCAR
  atoms = read(inputfile, format='vasp')
  atom_symbols = set(atoms.get_chemical_symbols())
  check_elements = elements.split('-')
  for element in check_elements:
    if element not in atom_symbols:
      print()
      print(" +===============================-===============================+")
      print(f"\033[31m [ERROR]\033[0m {element} not found in POSCAR file '{inputfile}'! Please retry.")
      return input_param()
  return inputfile, cutoff, elements
# Get parameters
inputfile, cutoff, elements = input_param()





# Create an argument parser
#parser = argparse.ArgumentParser(description='Calculate the average bond angle variance (σ2) for octahedron.')



# Parse the command-line arguments
#args = parser.parse_args()

# Read the input file in POSCAR format
atoms = read(inputfile, format='vasp')

# Extract elements from the provided argument
elementB, elementX = elements.split('-')

# Create NeighborList object
nl = NeighborList([cutoff / 2] * len(atoms), self_interaction=False, bothways=True)

# Set periodic boundary conditions
atoms.set_pbc(True)

# Update NeighborList object with atomic positions
nl.update(atoms)

# Store angles smaller than 120 degrees
angles = []

# Iterate over each elementB atom
for i, atom in enumerate(atoms):
    if atom.symbol == elementB:
        elementB_coord = atom.position

        # Get the 6 closest elementX atoms to the elementB atom
        indices, offsets = nl.get_neighbors(i)
        closest_elementXs = []
        for j, offset in zip(indices, offsets):
            if atoms[j].symbol == elementX:
                closest_elementXs.append((j, offset))

        # Sort by distance
        closest_elementXs.sort(
            key=lambda x: np.linalg.norm(atom.position - (atoms[x[0]].position + np.dot(x[1], atoms.get_cell()))))

        # Calculate all possible angles and store angles smaller than 120 degrees
        combinations_ = combinations(closest_elementXs[:6], 2)
        elementB_angles = []
        for comb in combinations_:
            elementX1, offset1 = comb[0]
            elementX2, offset2 = comb[1]
            elementX1_position = atoms[elementX1].position + np.dot(offset1, atoms.get_cell())
            elementX2_position = atoms[elementX2].position + np.dot(offset2, atoms.get_cell())
            angle = np.arccos(
                np.dot((elementX1_position - elementB_coord) / np.linalg.norm(elementX1_position - elementB_coord),
                       (elementX2_position - elementB_coord) / np.linalg.norm(elementX2_position - elementB_coord)))
            angle_deg = np.degrees(angle)
            if angle_deg < 120:
                elementB_angles.append(angle_deg)

        angles.append(elementB_angles)

# Modify and calculate average angles for each group of elementB atoms
modified_angles = []

# Process angles for each group of elementB atoms
for elementB_angles in angles:
    modified_elementB_angles = []
    for angle in elementB_angles:
        modified_angle = (angle - 90) ** 2
        modified_elementB_angles.append(modified_angle)
    
    # calculate the average values
    average_angle = sum(modified_elementB_angles) / 11
    modified_angles.append(average_angle)

# Print the results
print(" +===============================-===============================+")
print("\033[32m [SUCCESS]:\033[0m")
for i, angle in enumerate(modified_angles):
    print(f'    Bond angle variance (σ2) for {elementB}{i+1} octahedron: {angle:.4f}')
    
# Calculate the average of results
average_modified_angles = np.mean(modified_angles)

# Print the average of results
print(f"    Average values (σ2) for {len(modified_angles)} octahedron: {average_modified_angles:.4f}")
#print(" +===============================-===============================+")
