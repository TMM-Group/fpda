#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by mzkhalid039, https://github.com/mzkhalid039/Bond-lengths
# Modified by Gang Tang--2023.05.25

### Usage Commands ###
'''
 run the command: python bondlength-tg-input-bond-pairs.py POSCAR 6  Nb-O,B-O,K-O
 
 Note that "Nb-O,B-O" should not have spaces after the commas!!!!
'''
import os
import re
import spglib
from ase.io import read
from ase.neighborlist import neighbor_list
import matplotlib.pyplot as plt
import argparse
from collections import defaultdict
from collections import Counter
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  line_num=(len(line)-len(text)-2-2)//2
  prompt = "=" * line_num
  if len(text) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(text) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-------------------------------------------------------

files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
def parse_bond_pairs(s, inputfile):
    pairs = s.split('/')
    atoms = read(inputfile, format='vasp')
    atom_symbols = set(atoms.get_chemical_symbols())
    remove_indices = set()  #避免重复
    for i, pair in enumerate(pairs):
#    for pair in pairs:
        if '-' not in pair or pair == '-':
            print(" +===============================-===============================+")
            print("\033[31m [ERROR]\033[0m Element pairs '{}' must be separated by '-'! Please retry.".format(pair))
            remove_indices.add(i)
            continue
        check_elements = pair.split('-')
        for element in check_elements:
            if element not in atom_symbols:
                print(" +===============================-===============================+")
                print(f"\033[31m [ERROR]\033[0m {element} not found in POSCAR file '{inputfile}'! Please retry.")
                remove_indices.add(i)
    remove_indices = list(remove_indices) # 转换为列表
    for index in reversed(remove_indices):
        del pairs[index] #删除无效化学键
    return [(pair.split('-')[0].strip(), pair.split('-')[1].strip()) for pair in pairs]

def input_param():
  print(" +==========================Warm Prompt==========================+")
  print(" | Enter three parameters: inputfile cutoff elements             |")
  print(" | Or use '-' for default values.                                |")
  print(" |   inputfile  -- Input file name (default: POSCAR)             |")
  print(" |   cutoff     -- Cutoff radius (default: 3.3)                  |")
  print(" |   elements   -- Element pairs (separated by '-'and'/',        |")
  print(" |                                    e.g. H-He/Li-Bi/O-C)       |")
  print(" | Example:                                                      |")
  print(" |  'file 3.5 Fe-O/H-He' '- - Ti-O','- 1.5 F-Cl','file - Br-I'   |")
  print(" +===============================-===============================+")
    ##-----------------------打印当前文件价文件-------------------------------
    #print(" +===============================-===============================+")
  line_text("Current directory files")
  max_len = 57
  line_len = 0
  i=-1 #计数
  for file in files:
    i+=1
    if i == 0:
      print("  -", end='')  #单独为第一行打印 -
    if line_len + len(file) > max_len:
      print("\n", end='  -')
      line_len = 0  
    print(" "+file, end=', ')
    line_len += len(file) + 2
  #print("\n +===============================-===============================+")
  print("\n", end='')
  #-----------------------------------------------------------------
  ##输入参数
  print(" +===============================-===============================+")
  print(" Enter parameters (separated by space)\n 0) quit")
  print(" ************^-^*************")
  print("➤", end='')
  params = input().split()
  
  ##
  if params[0] == '0' and len(params) == 1:
    exit()
  if len(params) != 3:
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m Enter three parameters! Please retry.")
    return input_param()
  ##判断文件夹名是否存在
  inputfile = params[0]
  if inputfile == '-':
    inputfile = "POSCAR"
  if not os.path.exists(inputfile):
    print()
    print(" +===============================-===============================+")
    print("\033[31m [ERROR]\033[0m POSCAR file '"+inputfile+"' does not exist! Please retry.")
    return input_param()
  ##判断截断半径是否有效
  cutoff_str = params[1]
  if cutoff_str == '-':
    cutoff = 3.3
  else:
    try:
      cutoff = float(cutoff_str)
      if cutoff <= 0:
        print()
        print(" +===============================-===============================+")
        print("\033[31m [ERROR]\033[0m Cutoff must be greater than 0! Please retry.")
        return input_param()
    except ValueError:
      print()
      print(" +===============================-===============================+")
      print("\033[31m [ERROR]\033[0m Invalid cutoff value!")
      return input_param()
  ##判断输入元素是否有效
  elements = params[2]
  bond_pairs = parse_bond_pairs(elements, inputfile)
  return inputfile, cutoff, bond_pairs
# Get parameters
inputfile, cutoff, bond_pairs = input_param()
'''
parser = argparse.ArgumentParser(description='Calculate and plot bond lengths for given input file and cutoff distance.')
parser.add_argument('input_file', type=str, help='path to input file in POSCAR format')
parser.add_argument('cutoff', type=float, help='maximum distance to consider a bond')
parser.add_argument('bond_pairs', type=parse_bond_pairs, help='comma-separated list of bond pairs to calculate (e.g. "Nb-O,B-O,K-O")')
args = parser.parse_args()
'''
# Read in POSCAR file
poscar = read(inputfile, format="vasp")

# Run the space group analysis
data = (poscar.get_cell(), poscar.get_positions(), poscar.get_atomic_numbers())
result = spglib.get_symmetry_dataset(data)

# Generate list of nearest neighbors and calculate bond lengths
bond_lengths = defaultdict(list)
bond_pairs = set(tuple(sorted(pair)) for pair in bond_pairs)
neighbor_list_data = neighbor_list("ijdD", poscar, cutoff, self_interaction=False)
for i, atom in enumerate(poscar):
    symbol = atom.symbol
    neighbors = neighbor_list_data[0][neighbor_list_data[1] == i]
    for neighbor in neighbors:
        neighbor_symbol = poscar[neighbor].symbol
        distance = poscar.get_distance(i, neighbor)
        if distance < cutoff:
            bond_pair = tuple(sorted((symbol, neighbor_symbol)))
            if bond_pair in bond_pairs:
                bond_lengths[bond_pair].append(distance)

# Print bond lengths and count
for bond_pair in bond_lengths:
        print(" +===============================-===============================+")
        row1="{}-{} bond lengths: ".format(bond_pair[0], bond_pair[1])
        print(' |{:^63s}|'.format(row1))
#        print("{}-{} bond lengths: ".format(bond_pair[0], bond_pair[1]))
        counts = Counter(bond_lengths[bond_pair])
        for bond_length, count in counts.items():
            row2="{:.3f} Å - Count: {}".format(bond_length, count)
            print(' |{:^63s}|'.format(row2))
#            print("{:.3f} Å - Count: {}".format(bond_length, count))
        row3= "Total Count: {}".format(sum(counts.values()))
        print(' |{:^63s}|'.format(row3))
        avg = sum(bond_lengths[bond_pair]) / len(bond_lengths[bond_pair])
        row4="Average {}-{} bond length: {:.3f} Å".format(bond_pair[0], bond_pair[1], avg)
        print(' |{:^63s}|'.format(row4))
print(" +===============================-===============================+")

'''
for bond_pair in bond_lengths:
        print(" +===============================-===============================+")
        print(" | {}-{} bond lengths: |".format(bond_pair[0], bond_pair[1]))
        counts = Counter(bond_lengths[bond_pair])
        for bond_length, count in counts.items():
            print(" | {:.3f} Å - Count: {}|".format(bond_length, count))
        print(" | Total Count: {}|".format(sum(counts.values())))
        avg = sum(bond_lengths[bond_pair]) / len(bond_lengths[bond_pair])
        print(" | Average {}-{} bond length: {:.3f} Å|".format(bond_pair[0], bond_pair[1], avg))
print(" +===============================-===============================+")
'''

# Check for unprocessed bond pairs
unprocessed_bond_pairs = bond_pairs - set(bond_lengths.keys())
for bond_pair in unprocessed_bond_pairs:
    print("\033[33m [PROMPT]:\033[0m")
    print("    {}-{} bond lengths: Bond pair not found within cutoff range.".format(bond_pair[0], bond_pair[1]))
    print("    Consider increasing the cutoff value.")
'''
for bond_pair in bond_lengths:
    if len(bond_lengths[bond_pair]) = 0:
        tip = "cutoff value too small!"
    print("{}-{} bond lengths:{}".format(bond_pair[0], bond_pair[1], tip))
    for bond_length in bond_lengths[bond_pair]:
        print("{:.3f} Å".format(bond_length))
    print("Count: {}".format(len(bond_lengths[bond_pair])))
    avg = sum(bond_lengths[bond_pair]) / len(bond_lengths[bond_pair])
    print("Average {}-{} bond length: {:.3f} Å".format(bond_pair[0], bond_pair[1], avg))
'''
'''
# Plot bond lengths histograms
fig, axs = plt.subplots(1, len(bond_lengths), figsize=(3 * len(bond_lengths), 3))
for i, bond_pair in enumerate(bond_lengths):
    if len(bond_lengths) == 1:
        axs.hist(bond_lengths[bond_pair], bins=30)
        axs.set_xlabel("{}-{} bond length (Å)".format(bond_pair[0], bond_pair[1]))
        axs.set_ylabel("Count") 
    else:
        axs[i].hist(bond_lengths[bond_pair], bins=30)
        axs[i].set_xlabel("{}-{} bond length (Å)".format(bond_pair[0], bond_pair[1]))
        axs[i].set_ylabel("Count")
plt.tight_layout()
plt.show()
'''
