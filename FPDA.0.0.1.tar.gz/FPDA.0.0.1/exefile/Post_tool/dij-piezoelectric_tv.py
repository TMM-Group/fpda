#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.23

### Usage Commands ###
'''
First Step: put "OUTCAR (including Born effective charge)", "POSCAR.reference" and "POSCAR.polar"files in the same directory,  

Second Step: run the command: python bcpolarization_v2.py POSCAR.reference POSCAR.polar 
'''

import numpy as np
import os
files = os.listdir('.') # 当前目录
if 'OUTCARCij' not in files or 'OUTCARε_e' not in files:
  print("\033[31m [ERROR]\033[0m OUTCARCij or OUTCARε_e file not exist!")
  exit()

#+------------------------------ 读取弹性常数矩阵Ckj start ------------------------------+ 
idx_map = {
    'XX': 1,
    'YY': 2, 
    'ZZ': 3, 
    'XY': 6,
    'YZ': 4,
    'ZX': 5 
}
with open('OUTCARCij', 'r') as f:
    lines = f.readlines()   
# 找到"TOTAL ELASTIC MODULI (kBar)"这一行  
start_index = 0
for i, line in enumerate(lines):
    if 'TOTAL ELASTIC MODULI (kBar)' in line:
        start_index = i + 3
        break
if start_index == 0:
   print("\033[31m [ERROR]:\033[0m\n    Verify if the OUTCARCij file contains ELASTIC MODULI!")
   print("    Or some information of the OUTCARCij may be modified!")
   exit()
# 读取弹性常数矩阵        
elastic_constants = []
for line in lines[start_index:start_index+6]:
    elastic_constants.append([float(x) for x in line.split()[1:]])  

# 创建一个空字典存储弹性常数
elastic_dict = {}

for i in range(6):
    for j in range(6):
        # 如果常数不为0,则存储在字典中
        # 但键必须为Cij,i和j对应的是idx_map中的映射         
        if elastic_constants[i][j] != 0:   
            elastic_dict['C{}{}'.format(idx_map[lines[start_index+i].split()[0]],
                                       idx_map[lines[start_index+j].split()[0]])] = elastic_constants[i][j]


# 创建一个6x6的列表来表示矩阵
matrix = [[0 for j in range(6)] for i in range(6)]

# 将elastic_dict中的值填入matrix矩阵中
for key in elastic_dict:
    i = int(key[1])-1
    j = int(key[2])-1
    matrix[i][j] = elastic_dict[key] / 10

# 打印弹性常数矩阵Ckj,Skj-------------------------------------------------
'''
with open('ELASTIC_MODULI', 'w') as file:
    file.write('TOTAL ELASTIC MODULI (GPa)\n') 
    for i in range(6):
        file.write('{:9.4f} {:9.4f} {:9.4f} {:9.4f} {:9.4f} {:9.4f}\n'.format(
            matrix[i][0], matrix[i][1], matrix[i][2],
            matrix[i][3], matrix[i][4], matrix[i][5]))
'''
print("\033[36m           *** Starting to print elastic tensors Ckj *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
#print(" +---------------------------------------------------------------+")
for i in range(6):
    row = ' '.join('{:^8.4f}'.format(matrix[i][j]) for j in range(6))
    print(' |{:^63s}|'.format(row))
#print(" +---------------------------------------------------------------+")
print("\033[97m +===============================================================+\033[0m")

#print("\033[32m [SUCCESS]\033[0m ELASTIC_MODULI (GPa) file was written.")
print()

# 获取柔度矩阵Skj
compliance_matrix=np.linalg.inv(matrix)

print("\033[36m          *** Starting to print compliance tensors Skj *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(len(compliance_matrix)):
    row = ' '.join('{:^8.4f}'.format(compliance_matrix[i][j]) for j in range(len(compliance_matrix[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")

with open("compliance_tensors", 'w') as file:
   file.write('(1/GPa)\n')
   for i in range(len(compliance_matrix)):
       row = ' '.join('{:9.4f}'.format(compliance_matrix[i][j]) for j in range(len(compliance_matrix[i])))
       file.write(row + '\n')
'''
with open('compliance_tensors', 'w') as file:
    for i in range(6):
        file.write('{:9.4f} {:9.4f} {:9.4f} {:9.4f} {:9.4f} {:9.4f}\n'.format(
            compliance_matrix[i][0], compliance_matrix[i][1], compliance_matrix[i][2],
            compliance_matrix[i][3], compliance_matrix[i][4], compliance_matrix[i][5]))
'''
print("\033[32m [SUCCESS]\033[0m compliance_tensors (1/GPa) file was written.")
print()


#echo " +---------------------------------------------------------------+"
#+-------------------------------- 打印矩阵Ckj和Skj end ---------------------------------+ 

#+-------------------------------- 读取压电矩阵eik start --------------------------------+
def read_piezoelectric_tensor(filename, keywords, contr_type):
    with open(filename) as f:
        lines = f.readlines()

    # 找到OUTCAR中压电张量部分的起始行索引
    start_index = 0
    for i, line in enumerate(lines):
        for keyword in keywords:
            if keyword in line:
                start_index = i + 3
                break
        if start_index > 0:
            break
    end_index = start_index
    if start_index == 0:
       print("\033[31m [ERROR]:\033[0m\n    Verify if OUTCARε_e contains PIEZO TENSOR CONTR from "+contr_type+" !")
       print("    Or some information of the OUTCARε_e may be modified!")
       exit()
    # 读取压电张量数据
    piezoelectric_tensor_data = []
    for line in lines[end_index : end_index + 3]:
        piezoelectric_tensor_data.append([float(x) for x in line.split()[1:]])

        new_piezoelectric_tensor_data = []
    for column in zip(*piezoelectric_tensor_data):
        new_column = list(column)
        new_piezoelectric_tensor_data.append(new_column)
    # 交换列的顺序
    (
        new_piezoelectric_tensor_data[3],
        new_piezoelectric_tensor_data[4],
        new_piezoelectric_tensor_data[5],
    ) = (
        new_piezoelectric_tensor_data[4],
        new_piezoelectric_tensor_data[5],
        new_piezoelectric_tensor_data[3],
    )

    # 转置压电张量
    transposed_piezoelectric_tensor = list(
        map(list, zip(*new_piezoelectric_tensor_data))
    )

    return transposed_piezoelectric_tensor

elekeywords = ["PIEZOELECTRIC TENSOR  for field in x, y, z        (C/m^2)", 
               "PIEZOELECTRIC TENSOR (including local field effects)  for field in x, y, z        (C/m^2)"]
piezoelectric_tensor_ele = read_piezoelectric_tensor(
    "OUTCARε_e", elekeywords, "ele"
)
ionkeywords = ["PIEZOELECTRIC TENSOR IONIC CONTR  for field in x, y, z        (C/m^2)"]
piezoelectric_tensor_ion = read_piezoelectric_tensor(
    "OUTCARε_e", ionkeywords, "ion"
)

piezoelectric_tensor_sum = []
for i in range(3):
    piezoelectric_tensor_sum.append([piezoelectric_tensor_ele[i][j] + piezoelectric_tensor_ion[i][j]  
                          for j in range(6)]) 

# 打印压电矩阵eik

print("\033[36m        *** Starting to print piezoelectric tensors eik *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(len(piezoelectric_tensor_sum)):
    row = ' '.join('{:^8.4f}'.format(piezoelectric_tensor_sum[i][j]) for j in range(len(piezoelectric_tensor_sum[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")
'''
with open("piezoelectric_tensors", 'w') as file:
   file.write('TOTAL PIEZOELECTRIC TENSOR (C/m^2)\n')
   for i in range(len(piezoelectric_tensor_sum)):
       row = ' '.join('{:9.4f}'.format(piezoelectric_tensor_sum[i][j]) for j in range(len(piezoelectric_tensor_sum[i])))
       file.write(row + '\n')
print("\033[32m [SUCCESS]\033[0m piezoelectric_tensors (C/m^2)  file was written.")
'''
print()

#+--------------------------------- 打印压电矩阵eik end ---------------------------------+

#+-------------------------------- 计算压电矩阵dij start ------------------------------+ 
dij = np.zeros((3, 6)) #dij初始化

#units: eik: C/m2, Skj: 1/GPa, dij: pC/N
unit_conv = 1000 #单位转换系数

for i in range(1, 4):        # 行索引i从1到3
    for j in range(1, 7):    # 列索引j从1到6
        sum = 0
        for k in range(1, 7): # k从1到6循环
            sum += piezoelectric_tensor_sum[i-1][k-1] * compliance_matrix[k-1][j-1] * unit_conv
			#piezoelectric_tensor_sum: eik, compliance_matrix: Skj
        dij[i-1][j-1] = sum   # 保存dij的值

# 开始打印压电矩阵dij
print("\033[36m        *** Starting to print piezoelectric tensors dik *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(len(dij)):
    row = ' '.join('{:^8.4f}'.format(dij[i][j]) for j in range(len(dij[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")
with open("dij_piezo_strain_tensors", 'w') as file:
   file.write('PIEZOELECTRIC Strain TENSOR (pC/N)\n')
   for i in range(len(dij)):
       row = ' '.join('{:9.4f}'.format(dij[i][j]) for j in range(len(dij[i])))
       file.write(row + '\n')
print("\033[32m [SUCCESS]\033[0m dij_piezo_strain_tensors (pC/N) file was written.")

#+-------------------------------- 打印压电矩阵dij end --------------------------------+ 
