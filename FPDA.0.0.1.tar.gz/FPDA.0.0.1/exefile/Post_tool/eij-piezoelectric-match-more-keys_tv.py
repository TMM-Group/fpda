#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.23

### Usage Commands ###
'''
First Step: put "OUTCAR (including Born effective charge)", "POSCAR.reference" and "POSCAR.polar"files in the same directory,  

Second Step: run the command: python bcpolarization_v2.py POSCAR.reference POSCAR.polar 
'''
import re

import os
files = os.listdir('.') # 当前目录
if 'OUTCAR' not in files:
  print("\033[31m [ERROR]\033[0m OUTCAR file not exist!")
  exit()

def read_piezoelectric_tensor(filename, keywords, contr_type):
    with open(filename) as f:
        lines = f.readlines()

    # 找到OUTCAR中压电张量部分的起始行索引
    start_index = 0
    for i, line in enumerate(lines):
        for keyword in keywords:
            if keyword in line:
                start_index = i + 3
                break
        if start_index > 0:
            break
    end_index = start_index
    if start_index == 0:
       print("\033[31m [ERROR]:\033[0m\n    Verify if the OUTCAR contains PIEZO TENSOR CONTR from "+contr_type+" !")
       print("    Or some information of the OUTCAR may be modified!")
       exit()
    # 读取压电张量数据
    piezoelectric_tensor_data = []
    for line in lines[end_index : end_index + 3]:
        piezoelectric_tensor_data.append([float(x) for x in line.split()[1:]])

        new_piezoelectric_tensor_data = []
    for column in zip(*piezoelectric_tensor_data):
        new_column = list(column)
        new_piezoelectric_tensor_data.append(new_column)
    # 交换列的顺序
    (
        new_piezoelectric_tensor_data[3],
        new_piezoelectric_tensor_data[4],
        new_piezoelectric_tensor_data[5],
    ) = (
        new_piezoelectric_tensor_data[4],
        new_piezoelectric_tensor_data[5],
        new_piezoelectric_tensor_data[3],
    )

    # 转置压电张量
    transposed_piezoelectric_tensor = list(
        map(list, zip(*new_piezoelectric_tensor_data))
    )

    return transposed_piezoelectric_tensor

elekeywords = ["PIEZOELECTRIC TENSOR  for field in x, y, z        (C/m^2)", 
               "PIEZOELECTRIC TENSOR (including local field effects)  for field in x, y, z        (C/m^2)"]
piezoelectric_tensor_ele = read_piezoelectric_tensor(
    "OUTCAR", elekeywords, "ele"
)
ionkeywords = ["PIEZOELECTRIC TENSOR IONIC CONTR  for field in x, y, z        (C/m^2)"]
piezoelectric_tensor_ion = read_piezoelectric_tensor(
    "OUTCAR", ionkeywords, "ion"
)

piezoelectric_tensor_sum = []
for i in range(3):
    piezoelectric_tensor_sum.append([piezoelectric_tensor_ele[i][j] + piezoelectric_tensor_ion[i][j]  
                          for j in range(6)]) 

# 打印矩阵
print("\033[36m          *** Starting to print ele piezo tensors eik *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(3):
    row = ' '.join('{:^8.4f}'.format(piezoelectric_tensor_ele[i][j]) for j in range(len(piezoelectric_tensor_ele[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")

print()
print("\033[36m          *** Starting to print ion piezo tensors eik *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(3):
    row = ' '.join('{:^8.4f}'.format(piezoelectric_tensor_ion[i][j]) for j in range(len(piezoelectric_tensor_ion[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")

print()
print("\033[36m          *** Starting to print sum piezo tensors eik *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(3):
    row = ' '.join('{:^8.4f}'.format(piezoelectric_tensor_sum[i][j]) for j in range(len(piezoelectric_tensor_sum[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")
#写入文件
with open('eij_piezo_stress_tensors', 'w') as f:
    f.write(' Electronic contribution:\n')
    for row in piezoelectric_tensor_ele:
        f.write(f' {row[0]:>10.5f} {row[1]:>10.5f} {row[2]:>10.5f} {row[3]:>10.5f} {row[4]:>10.5f} {row[5]:>10.5f}\n')

    f.write('\n Ionic contribution:\n')
    for row in piezoelectric_tensor_ion:
        f.write(f' {row[0]:>10.5f} {row[1]:>10.5f} {row[2]:>10.5f} {row[3]:>10.5f} {row[4]:>10.5f} {row[5]:>10.5f}\n')

    f.write('\n Total (C/m^2) :\n')
    for row in piezoelectric_tensor_sum:
        f.write(f' {row[0]:>10.5f} {row[1]:>10.5f} {row[2]:>10.5f} {row[3]:>10.5f} {row[4]:>10.5f} {row[5]:>10.5f}\n')
'''
with open('piezoelectric_tensor', 'r') as f:
    print(f.read())
'''
print("\033[32m [SUCCESS]\033[0m eij_piezo_stress_tensors (C/m^2) file was written.")
