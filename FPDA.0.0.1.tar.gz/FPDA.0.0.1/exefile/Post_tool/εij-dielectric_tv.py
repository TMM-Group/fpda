#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.23

### Usage Commands ###
'''
First Step: put "OUTCAR (including Born effective charge)", "POSCAR.reference" and "POSCAR.polar"files in the same directory,  

Second Step: run the command: python bcpolarization_v2.py POSCAR.reference POSCAR.polar 
'''
import os
files = os.listdir('.') # 当前目录
if 'OUTCAR' not in files:
  print("\033[31m [ERROR]\033[0m OUTCAR file not exist!")
  exit()

def read_dielectric_tensor(filename, keyword, contr_type):
    dielectric_tensor = []
    with open(filename) as f:
        lines = f.readlines()
    last_index = 0 
    for i, line in enumerate(lines):
        if keyword in line:  
            last_index = i + 2 
    start_index = last_index  
    if last_index == 0:
       print("\033[31m [ERROR]:\033[0m\n    Verify if the OUTCAR contains MACROSCOPIC STATIC DIELECTRIC\n    TENSOR CONTR from "+contr_type+" !")
       print("    Or some information of the OUTCAR may be modified!")
       exit()    
    for line in lines[start_index:start_index+3]:
        dielectric_tensor.append([float(x) for x in line.split()])
    return dielectric_tensor



dielectric_tensor_ele = read_dielectric_tensor('OUTCAR',  
                       'MACROSCOPIC STATIC DIELECTRIC TENSOR (including local field effects in DFT)', "ele")
dielectric_tensor_ion = read_dielectric_tensor('OUTCAR',  
                         'MACROSCOPIC STATIC DIELECTRIC TENSOR IONIC CONTRIBUTION', "ion")

dielectric_tensor_sum = []  
for i in range(3):
    dielectric_tensor_sum.append([dielectric_tensor_ele[i][j] + dielectric_tensor_ion[i][j]  
                  for j in range(3)])
#打印数据
print("\033[36m        *** Starting to print ele dielectric tensors εij *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(len(dielectric_tensor_ele)):
    row = ' '.join('{:^12.4f}'.format(dielectric_tensor_ele[i][j]) for j in range(len(dielectric_tensor_ele[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")

print()
print("\033[36m        *** Starting to print ion dielectric tensors εij *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(len(dielectric_tensor_ion)):
    row = ' '.join('{:^12.4f}'.format(dielectric_tensor_ion[i][j]) for j in range(len(dielectric_tensor_ion[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")

print()
print("\033[36m        *** Starting to print sum dielectric tensors εij *** \033[0m")
print("\033[97m +===============================================================+\033[0m")
for i in range(len(dielectric_tensor_sum)):
    row = ' '.join('{:^12.4f}'.format(dielectric_tensor_sum[i][j]) for j in range(len(dielectric_tensor_sum[i])))
    print(' |{:^63s}|'.format(row))
print("\033[97m +===============================================================+\033[0m")
#写入数据
with open("dielectric_tensors", 'w') as file:
   file.write('ele\n')
   for i in range(len(dielectric_tensor_ele)):
       row = ' '.join('{:9.4f}'.format(dielectric_tensor_ele[i][j]) for j in range(len(dielectric_tensor_ele[i])))
       file.write(row + '\n')
       
   file.write('ion\n')
   for i in range(len(dielectric_tensor_ion)):
       row = ' '.join('{:9.4f}'.format(dielectric_tensor_ion[i][j]) for j in range(len(dielectric_tensor_ion[i])))
       file.write(row + '\n')
       
   file.write('sum\n')
   for i in range(len(dielectric_tensor_sum)):
       row = ' '.join('{:9.4f}'.format(dielectric_tensor_sum[i][j]) for j in range(len(dielectric_tensor_sum[i])))
       file.write(row + '\n')
print("\033[32m [SUCCESS]\033[0m dielectric_tensors file was written.")
