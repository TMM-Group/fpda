#!/bin/bash

cat >strained_poscar_relax.sh<<eof
#!/bin/bash

mkdir relax_strained_POSCAR
for i in \$(ls strained_POSCAR)
do
mkdir relax_strained_POSCAR/\$i
cp strained_POSCAR/\$i relax_strained_POSCAR/\$i
#cp INCAR KPOINTS POTCAR job relax_strained_POSCAR/\$i
#sub relax_strained_POSCAR/\$i/job
done       
eof
echo -e " \e[1;32m[SUCCESS]\e[0m strained_poscar_relax.sh file was written! "
