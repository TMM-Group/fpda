#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.06.01

### Usage Commands ###
'''
 run the command: python apply-strain.py  
'''
##--还需要更优雅处理用户输入校验--##
import numpy as np
from pymatgen.core import Structure
from pymatgen.symmetry.analyzer import SpacegroupAnalyzer
from pymatgen.transformations.standard_transformations import DeformStructureTransformation
#https://pymatgen.org/pymatgen.analysis.elasticity.strain.html
import re
import os
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------
##默认文件POSCAR
POSCAR='POSCAR'
##判断文件是否在当前目录
if not os.path.exists(POSCAR):
   line_text('')
   print(f"\033[31m [ERROR]\033[0m {POSCAR} not exist! Please retry.")
   exit()
# 读取原胞结构
poscar_file = POSCAR  # 原胞结构的POSCAR文件
structure = Structure.from_file(poscar_file)

#选择应变方式
line_text('Option')
print(" 1)  Tension or compress \n 2)  Pure shear \n 3)  Simple shear")
print("\n Choose the way to apply strain")
print(" 0)  Quit")
print(" ************^-^*************")
print("➤", end='')

param1 = input()
param1 = list(filter(None, param1.split(' ')))  #filter 去除空值
##-------------判断输入参数是否为一位整数0-4----------------
if len(param1) != 1:
    line_text('')
    print("\033[31m [ERROR]\033[0m Invalid input! Please enter only an integer!")
    exit()
try:
  param1 = int(param1[0])
  if not (0 <= param1 < 4):
    line_text('')
    print("\033[31m [ERROR]\033[0m Enter an integer between 0 and 3!")
    exit()
except ValueError:
  line_text('')
  print("\033[31m [ERROR]\033[0m Enter an integer between 0 and 3!!")  
  exit()
 #------------------ ----------------
if param1 == 0:
    exit()
#选择应变矩阵元
def selection_matrix_element():
    line_text(" Select the strain matrix element")
#    print(f"""
#    {0:4} {1:4} {2:4}
#    {0:4} {'XX':4} {'XY':4} {'XZ':4}  
#    {1:4} {'YX':4} {'YY':4} {'YZ':4}
#    {2:4} {'ZX':4} {'ZY':4} {'ZZ':4}
#    """)
    print(' |{:^71s}|'.format("\033[4m  │ 0    1    2 \033[0m"))
    print(' |{:^63s}|'.format("0 │X X  X Y  X Z"))
    print(' |{:^63s}|'.format("1 │Y X  Y Y  Y Z"))
    print(' |{:^63s}|'.format("2 │Z X  Z Y  Z Z"))
    line_text('')
    if  param1 == 1 or param1 == 3:
      print(" Enter one 2-digits number like '22'\n 0) quit ")
    else:
      print(" Enter two 2-digit numbers separated by space, like '11 22' \n 0) quit ")
    print(" ************^-^*************")
    print("➤", end='')
    param2 = input()
    param2 = list(filter(None, param2.split(' ')))  #filter 去除空值
    if len(param2) == 1 and param2[0] == '0':
       exit()
    if  param1 == 1 or param1 == 3:
        if len(param2) == 1 :
          separated = [char for char in param2[0]]
          if len(separated) !=2 :
              line_text('')
              print("\033[31m [ERROR]\033[0m Invalid number! Enter two digits like '00'.")
              exit()
          if separated[0] not in '012' or separated[1] not in '012':
              line_text('')
              print("\033[31m [ERROR]\033[0m Invalid number! Enter two digits like '00'.")
              exit()
          num1 = int(separated[0])
          num2 = int(separated[1])
          return num1, num2    
        else:
          line_text('')
          print("\033[31m [ERROR]\033[0m I HOPE YOU KNOW HOW TO APPLY STRAIN!")
          exit()
    if param1 == 2:
      if len(param2) == 2:
        pure_num1= [char for char in param2[0]]
        pure_num2= [char for char in param2[1]]
        if len(pure_num1) != 2 or len(pure_num2) != 2:
            line_text('')
            print("\033[31m [ERROR]\033[0m Invalid input! Enter two digits like '00 11'.")
            exit()
        if pure_num1[0] not in '012' or pure_num1[1] not in '012' or pure_num2[0] not in '012' or pure_num2[1] not in '012':
            line_text('')
            print("\033[31m [ERROR]\033[0m Invalid input! Enter two digits like '00 12'")
            exit()
        num1 = int(pure_num1[0])
        num2 = int(pure_num1[1])
        num3 = int(pure_num2[0])
        num4 = int(pure_num2[1])
        return num1, num2, num3, num4
      else:
        line_text('')
        print("\033[31m [ERROR]\033[0m I HOPE YOU KNOW HOW TO APPLY STRAIN!")
        exit()  
#row1,col1 = selection_matrix_element()
if param1 == 1 or param1 == 3:
  row1,col1 = selection_matrix_element()
elif param1 == 2:
  row1,col1,row2,col2 = selection_matrix_element()
#row1, col1, row2, col2 = selection_matrix_element()
# 定义应变比例范围（-1.5%到1.5%)
#def define_strain_range():
print(" +===============================-===============================+")
print(" Please enter 'start end step' separated by space,\n for example '-1.5 1.5 0.5' Unit(%):")
print(" 0)  Quit")
print(" ************^-^*************")
print("➤", end='')
range_input = input()
range_input = list(filter(None, range_input.split(' ')))  #filter 去除空值
if len(range_input) == 1 and range_input[0] == '0':
   exit()
if len(range_input) != 3: 
    line_text('')
    print('\033[31m [ERROR]\033[0m Invalid input!')
    exit()
start, end, step = range_input
try:
    start = float(start)
    end = float(end)
    step = float(step)
    if not (start >= -100 and start <= 100) or not (end >= -100 and end <= 100):
       line_text('')
       print("\033[31m [ERROR]\033[0m Invalid input! Check 'start' and 'end'.")
       exit()
except ValueError:
    line_text('')
    print('\033[31m [ERROR]\033[0m Invalid input!')
    exit()
strain_range = np.arange(start, end+0.0001, step)
##新建目录
directory = "strained_POSCAR"
new_directory = "old-" + directory
if not os.path.exists(directory):
    os.mkdir(directory)
else:
    os.rename(directory, new_directory)
    os.mkdir(directory)
    print(f"\033[31m [NOTE]\033[0m strained_POSCAR directory exists and renamed to: {new_directory}")
# 应用不同的应变比例并写入文件
for i, strain_ratio in enumerate(strain_range):
    # 创建拉伸或者压缩应变矩阵
    strain_matrix = np.eye(3)
    if param1 == 1:
        strain_matrix[row1, col1] = 1 + strain_ratio / 100  #zz方向施加拉伸/压缩应变
    elif param1 == 2:
    # pure shear
        strain_matrix[row1, col1] = strain_ratio / 200  # xy方向的剪切应变
        strain_matrix[row2, col2] = strain_ratio / 200  # yx方向的剪切应变
    elif param1 == 3:
    # simple shear
        strain_matrix[row1, col1] = strain_ratio / 100  # xy方向的剪切应变
    
    
    # 创建应变转换对象
    strain_transformation = DeformStructureTransformation(strain_matrix)
    
    # 应用应变转换到原胞结构
    strained_structure = strain_transformation.apply_transformation(structure)
    
    # 构造文件名
    filename = f"{directory}/{i:02}strained_POSCAR_{strain_ratio}%.vasp"
    
    # 将施加应变后的结构写入文件
    strained_structure.to(filename=filename)
print("\033[32m [SUCCESS]\033[0m  Please check strained_POSCAR directory.")
