#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.27

### Usage Commands ###
'''
run the command: python atom-position-difference-v2.py  POSCAR.reference  POSCAR.polar
'''
'''
目前仅能运算基石完全相同，是否考虑微小基石误差可以忽略的情况？？
'''
from ase import Atoms
from ase.io import read
import numpy as np
import argparse
import os
import re
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------

#--------------读取当前目录文件去除隐藏文件----------------
files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
#---------------------------------------------------------------------------

##-----------------------打印当前文件价文件-------------------------------
#print(" +===============================-===============================+")
line_text("Current directory files")
max_len = 57
line_len = 0
i=-1 #计数
for file in files:
  i+=1
  if i == 0:
    print("  -", end='')  #单独为第一行打印 -
  if line_len + len(file) > max_len:
    print("\n", end='  -')
    line_len = 0  
  print(" "+file, end=', ')
  line_len += len(file) + 2
#print("\n +===============================-===============================+")
print("\n", end='')
#--------------------------------------------------------------------

##-------------------------------输入选项-------------------
line_text("Option")
print(" 1)  Read the IS and FS files by default.\n 0)  Quit")
print(" Or) Enter two structure file names (separated by space).")
print(" ************^-^*************")
print("➤", end='')
param = input()
parts = list(filter(None, param.split(' ')))  #filter 去除空值
#---------------------------------------------------

#--------------------控制默认文件名--------------
IS="IS"
FS="FS"
#---------------------------------------------

#-------------判断输入参数有效性,正确读取结构信息----------------
if parts[0] == '1' and len(parts) == 1:
  # 没有逗号,parts只包含整个参数
  if IS not in files or FS not in files:
    print(f"\033[31m [ERROR]\033[0m '{IS}' or '{FS}' file not exist!")
    exit()
  structure1 = read(IS, format='vasp')
  structure2 = read(FS, format='vasp')
elif parts[0] == '0' and len(parts) == 1:
  exit()
elif len(parts) == 2:
  # 有一个逗号,分割为两个部分
  if f'{parts[0]}' not in files:
    print(f"\033[31m [ERROR]\033[0m '{parts[0]}' file not exist!")
    exit()
  elif f'{parts[1]}' not in files:
    print(f"\033[31m [ERROR]\033[0m '{parts[1]}' file not exist!")
    exit()
  structure1 = read(parts[0], format='vasp')
  structure2 = read(parts[1], format='vasp')

else:
  # 多个逗号,错误
  print('\033[31m [ERROR]\033[0m Invalid input! Please enter only two file names.')
  exit()
#-------------------------------------------------------------------------

#-------------数据运算-------------------------
# Calculate the absolute difference of atomic coordinates
coords1 = structure1.get_positions()
coords2 = structure2.get_positions()
diff = coords2 - coords1  #
# 计算原子位移矢量
#displacements = get_distances(positions1, positions2, mic=True)

# Set the precision for printing and saving
np.set_printoptions(precision=10, suppress=True)

# Get lattice constants
lattice_constants1 = structure1.cell.cellpar()[:3]
lattice_constants2 = structure2.cell.cellpar()[:3]
#--------------------------------------------------------

###-----------------------打印，写入 函数---------------------------------
def matrix_print(matrix_name, filename, width_precision='8.4', text='', title=''):  # width_precision 默认值为 '8.4'
    with open(filename, 'w') as file:
      file.write(title+'\n')
      line_text(text)
      for i in range(len(matrix_name)):
          row = ' '.join('{:^{wp}f}'.format(matrix_name[i][j], wp=width_precision) for j in range(len(matrix_name[i])))
          print(' |{:^63s}|'.format(row))
          file.write(row + '\n')
    print(" +===============================-===============================+")
    print(f"\033[32m [SUCCESS]\033[0m {filename} file was written.")
#-----------------------------------------------------------------------------------
# Compare the lattice constants
if np.allclose(lattice_constants1, lattice_constants2):
    print(" +===============================-===============================+")
    print(" Lattice constants are the same.")
    matrix_print(diff, "Atomic_coo_differences", width_precision='12.4',text='Atomic coordinate differences' )
else:
    print("\033[31m [ERROR]\033[0m Lattice constants are different！！！")
