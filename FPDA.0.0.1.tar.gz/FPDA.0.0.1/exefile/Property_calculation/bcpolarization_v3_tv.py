#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.15
# Modified by Gang Tang--2023.06.01
# References: https://github.com/mzkhalid039/Polarization-Born-charges/blob/main/bcpolarization.py

### Usage Commands ###
'''
First Step: put "OUTCAR (including Born effective charge)", "POSCAR.reference" and "POSCAR.polar"files in the same directory,  

Second Step: run the command: python bcpolarization_v3.py POSCAR.reference POSCAR.polar 
'''
from pymatgen.io.vasp import Poscar
import numpy as np
import sys
import os
import re
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------

#--------------读取当前目录文件去除隐藏文件----------------
files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
#---------------------------------------------------------------------------

##-----------------------打印当前文件价文件-------------------------------
#print(" +===============================-===============================+")
line_text("Current directory files")
max_len = 57
line_len = 0
i=-1 #计数
for file in files:
  i+=1
  if i == 0:
    print("  -", end='')  #单独为第一行打印 -
  if line_len + len(file) > max_len:
    print("\n", end='  -')
    line_len = 0  
  print(" "+file, end=', ')
  line_len += len(file) + 2
#print("\n +===============================-===============================+")
print("\n", end='')
#--------------------------------------------------------------------

##-------------------------------输入选项-------------------
line_text("\033[31mPlease Note\033[0m")
print(" Enter the refer \033[31mbefore\033[0m the polar phase!!")
print(" Put 'OUTCAR' with Born effective charge in current dir.")
line_text("Option")
print(" 1)  Read the refer and polar files by default.\n 0)  Quit")
print(" Or) Enter two structure file names (separated by space).")
#print("     - Put the refer \033[31mbefore\033[0m the polar phase!!")
#print("     - Put 'OUTCAR' with Born effective charge in current dir.")
print(" +===============================-===============================+")
print(" ************^-^*************")
print("➤", end='')
param = input()
param = list(filter(None, param.split(' ')))  #filter 去除空值
#---------------------------------------------------
#----------------判断OUTCAR是否存在-------------------
if 'OUTCAR' not in files:
  print("\033[31m [ERROR]\033[0m OUTCAR file not exist!")
  exit()
#------------------------------------------------------
#-------------控制默认文件名-----------------------
IS="refer"
FS="polar"
##---------------------------------------------------------

##-------------------------判断输入选项,正确读取结构---------------------
if param[0] == '1' and len(param) == 1:
  # 没有逗号,parts只包含整个参数
  if IS not in files or FS not in files:
    print(f"\033[31m [ERROR]\033[0m '{IS}' or '{FS}' file not exist!")
    exit()
#  structure1 = read(IS, format='vasp')
#  structure2 = read(FS, format='vasp')
  ref_structure_file = IS
  polar_structure_file = FS

elif param[0] == '0' and len(param) == 1:
  exit()
elif len(param) == 2:
  # 如果空格分割,分割为两个有效部分
  if f'{param[0]}' not in files:
    print(f"\033[31m [ERROR]\033[0m '{param[0]}' file not exist!")
    exit()
  elif f'{param[1]}' not in files:
    print(f"\033[31m [ERROR]\033[0m '{param[1]}' file not exist!")
    exit()
#  structure1 = read(parts[0], format='vasp')
#  structure2 = read(parts[1], format='vasp')
  ref_structure_file = param[0]
  polar_structure_file = param[1]

else:
  # 多个逗号,错误
  print('\033[31m [ERROR]\033[0m Invalid input! Please enter only two file names.')
  exit()
#--------------------------------end----------------------------------------------
  
def read_coordinate(POSCAR):
    with open(POSCAR, 'r') as f:
        lines = f.readlines()
        #使用python库读取poscar坐标，以防 坐标后面出现 ！N   而读取不了
        p = Poscar.from_file(POSCAR)
        coo = [site.frac_coords for site in p.structure]
        atoms_coord =np.array([coord.tolist() for coord in coo]) #将数组转为列表
        # 使用列表推导式和map()函数读取晶格矢量、原子数和坐标
        lattice = np.array([list(map(float, line.split()[:3])) for line in lines[2:5]])
        atom_types = lines[5].split()
        num_atoms = list(map(int, lines[6].split()))
#        atoms_coord = np.array([list(map(float, line.split()[:3])) for line in lines[8:sum(num_atoms)+8]])
    return lattice, atom_types, num_atoms, atoms_coord

# 读取两个POSCAR文件并分别获取晶格矢量、原子数和坐标
latt0, atomtype0, atomnum0, coord0 = read_coordinate(ref_structure_file)
latt1, atomtype1, atomnum1, coord1 = read_coordinate(polar_structure_file)

# 构造原子类型列表
atom_list = []
for i, atom_type in enumerate(atomtype1):
    atom_list += [atom_type] * atomnum1[i]

# 判断两个晶格矢量是否相同
if np.allclose(latt0, latt1):
    pass
else:
    print("\033[31m [NOTE]:\033[0m\n    Inconsistent lattice parameters between para and ferro phases!")
    print("    I HOPE YOU KNOW WHAT YOU ARE DOING.")
# 计算两个POSCAR文件中原子坐标的差值
delta_pos = coord1 - coord0

# 使用矩阵乘法计算差值坐标在latt1下的坐标
delta_pos_C = np.matmul(delta_pos, latt1)

# 读取OUTCAR中波恩有效电荷数据
with open('OUTCAR') as f:
    lines = f.readlines()
    for line in lines:
        if 'volume of cell' in line:
            volume = float(line.split(':')[1].split()[0])

    start_line = 0
    for i, line in enumerate(lines):
        if 'BORN EFFECTIVE CHARGES' in line:
            start_line = i
            break
    if start_line == 0:
        print("\033[31m [ERROR]:\033[0m\n    Verify if the OUTCAR file contains BORN EFFECTIVE CHARGES!")
        print("    Or some information of the OUTCAR may be modified!")
        exit()
    end_line = start_line + sum(atomnum1)*4+2
    born = lines[start_line:end_line]

# Extract relevant data from born and write to file
new_born = [line.split()[1:] for line in born if line.startswith('    1') or line.startswith('    2') or line.startswith('    3')]
new_born = np.array([[float(x), float(y), float(z)] for x, y, z in new_born])

# 根据公式计算极化值
#p = dipole / volume, p: μC/cm2; dipole: eÅ; volume: Å3; 1 Elementary charge [e] = 1.602176565 ×10-19 Coulomb [C].  
Conv = 1602.176565 # Value of Conv
polarization = [] 

for i in range(len(delta_pos_C)):
    start_index = i * 3
    end_index = start_index + 3
    new_born_matrix = new_born[start_index:end_index, :]
    delta_pos_C_vector = delta_pos_C[i, :]
    polarization_vector = np.dot(new_born_matrix, delta_pos_C_vector) / volume*Conv
    polarization.append(polarization_vector)

polarization_all = np.sum(polarization, axis=0) 
   

# 将两个POSCAR文件中原子坐标的差值写入文件 #np.savetxt('difference.dat', delta_pos, fmt='%.6f')
with open('atom-position-diff.dat', 'w', encoding='utf-8') as f:
    for posc, atom in zip(delta_pos_C, atom_list):
        f.write(f'{posc[0]:12.6f} {posc[1]:12.6f} {posc[2]:12.6f}  {atom} (Unit: Å)\n')
    '''
    for dx, dy, dz in delta_pos:
        f.write(f"{dx:.6f} {dy:>12.6f} {dz:>12.6f}\n")
    '''

# 将Born effective charge写入文件 
with open('born.dat', 'w', encoding='utf-8') as f:
    for i, atom in enumerate(atom_list):
        f.write(f"ion {i+1} ({atom}) (Unit: e) \n")
        for j in range(3):
            pos = new_born[3 * i + j]
            f.write(f"{pos[0]:12.5f}   {pos[1]:12.5f}   {pos[2]:12.5f}\n")
            
# 将原子分解的极化值写入文件 
with open('ion-decomp-polarvalue.dat', 'w', encoding='utf-8') as f:
    for polar, atom in zip(polarization, atom_list):
        f.write(f"{polar[0]:12.6f} {polar[1]:12.6f} {polar[2]:12.6f}  {atom}  (Unit: \N{GREEK SMALL LETTER MU}C/cm²)\n")

# 将极化矢量写入文件
with open('allpolarization.dat', 'w', encoding='utf-8') as f:
	 f.write(f"{polarization_all[0]:.3f}\t{polarization_all[1]:.3f}\t{polarization_all[2]:.3f} (Unit: \N{GREEK SMALL LETTER MU}C/cm²) \n") 
	
# 输出总的极化矢量在x、y、z轴上的分量
line_text("Polarization")
print(f" Final polarization along x-axis: {polarization_all[0]:.3f} \N{GREEK SMALL LETTER MU}C/cm²")
print(f" Final polarization along y-axis: {polarization_all[1]:.3f} \N{GREEK SMALL LETTER MU}C/cm²")
print(f" Final polarization along z-axis: {polarization_all[2]:.3f} \N{GREEK SMALL LETTER MU}C/cm²")
line_text('')
print("\033[32m [SUCCESS]\033[0m\n    atom-position-diff.dat was written.\n    born.dat was written.\n    allpolarization.dat was written.")
