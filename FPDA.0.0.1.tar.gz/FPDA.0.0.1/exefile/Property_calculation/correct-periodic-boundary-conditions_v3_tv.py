#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.27

### Usage Commands ###
'''
run the command: python correct-periodic-boundary-conditions_v2.py POSCAR.reference POSCAR.polar
'''

'''
>>>>由于数据的读取和写入并不是使用相关库，selective 和 坐标后的注释 ！N  的读取和写入 可能存在问题！！！！！！！！！！
>>>> 功能有待完善，是否只考虑存在只对极化的方向调整结构？？对于二元可以计算某方向位移矢量和 判断极化。  三元。。。？
'''


import numpy as np
from pymatgen.io.vasp import Poscar
import sys
import os
import re
#请确认极化相结构的正确性，参考相将根据此结构做出调整。
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------

#--------------读取当前目录文件去除隐藏文件----------------
files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件
#---------------------------------------------------------------------

##----------------------打印当前目录文件价文件----------------------------
line_text("Current directory files")
max_len = 57
line_len = 0
i=-1 #计数
for file in files:
  i+=1
  if i == 0:
    print("  -", end='')
  if line_len + len(file) > max_len:
    print("\n", end='  -')
    line_len = 0  
  print(" "+file, end=', ')
  line_len += len(file) + 2
print("\n", end='')
#---------------------------end-------------------------------------

#print("\n +===============================-===============================+")
##-----------------------输入选项 start-------------------------
line_text("Option")
print(" 1)  Read the refer and polar files by default.\n 0)  Quit")
print(" Or) Enter two structure file names (separated by space).")
print("     - Input the refer phase \033[31mbefore\033[0m the polar phase!!")
print(" ************^-^*************")
print("➤", end='')
param = input().split()  #会去除空值
#----------------------------------------------------------

#parts = list(filter(None, param.split(' ')))  #filter 去除空
#-------------控制默认文件名-----------------------
IS="refer"
FS="polar"
##---------------------------------------------------------

##-------------------------判断输入选项,正确读取结构---------------------
if param[0] == '1' and len(param) == 1:
  # 没有逗号,parts只包含整个参数
  if IS not in files or FS not in files:
    print(f"\033[31m [ERROR]\033[0m '{IS}' or '{FS}' file not exist!")
    exit()
#  structure1 = read(IS, format='vasp')
#  structure2 = read(FS, format='vasp')
  ref_structure_file = IS
  polar_structure_file = FS

elif param[0] == '0' and len(param) == 1:
  exit()
elif len(param) == 2:
  # 如果空格分割,分割为两个有效部分
  if f'{param[0]}' not in files:
    print(f"\033[31m [ERROR]\033[0m '{param[0]}' file not exist!")
    exit()
  elif f'{param[1]}' not in files:
    print(f"\033[31m [ERROR]\033[0m '{param[1]}' file not exist!")
    exit()
#  structure1 = read(parts[0], format='vasp')
#  structure2 = read(parts[1], format='vasp')
  ref_structure_file = param[0]
  polar_structure_file = param[1]

else:
  # 多个逗号,错误
  print('\033[31m [ERROR]\033[0m Invalid input! Please enter only two file names.')
  exit()
#--------------------------------end----------------------------------------------

####
def read_poscar(filename):
    with open(filename, 'r') as f:
        lines = f.readlines()
    #使用python库读取poscar坐标，以防 坐标后面出现 ！N   而读取不了
    p = Poscar.from_file(filename)
    coo = [site.frac_coords for site in p.structure]
    atom_coords = [coord.tolist() for coord in coo] #将数组转为列表
    
    lattice_vectors = [list(map(float, lines[i].split())) for i in range(2, 5)]
    atom_count = [int(num) for num in lines[6].split()]
#    atom_coords = [list(map(float, line.split())) for line in lines[8:8+sum(atom_count)]]       ## 坐标后面出现 ！N   而读取不了
    element_names = lines[5].split()
    return lattice_vectors, atom_count, atom_coords, element_names

def write_poscar(filename, lattice_vectors, atom_count, atom_coords, element_names):
    with open(filename, 'w') as f:
        f.write("New Structure\n")
        f.write("1.0\n")
        for vector in lattice_vectors:
            f.write("{:.10f} {:.10f} {:.10f}\n".format(*vector))
        f.write(" ".join(element_names) + "\n")
        f.write(" ".join(str(count) for count in atom_count) + "\n")
        f.write("Direct\n")
        for coords in atom_coords:
            f.write("{:.10f} {:.10f} {:.10f}\n".format(*coords))

def compare_coordinates(coords1, coords2):
    diff_coords = []
    for i in range(len(coords1)):
        if coords1[i] != coords2[i]:
            diff_coords.append(i)
    return diff_coords


# Read the reference structure data
lattice_vectors1, atom_count1, atom_coords1, element_names1 = read_poscar(ref_structure_file)

# Read the polar structure data
lattice_vectors2, atom_count2, atom_coords2, element_names2 = read_poscar(polar_structure_file)

# Compare the atomic coordinates for each atom
new_atom_coords = []
for coords1, coords2 in zip(atom_coords1, atom_coords2):
    new_coords = []
    for coord1, coord2 in zip(coords1, coords2):
        diff = coord2 - coord1
        if diff < -0.5:
            new_coords.append(coord1 - 1)
        elif diff >= 0.5:
            new_coords.append(coord1 + 1)
        else:
            new_coords.append(coord1)
    new_atom_coords.append(new_coords)

# Compare the coordinates between the original and new structures
#print("\033[36m >> Comparing atomic coordinates between the original and new reference structures: \033[0m \n")

diff_indices = compare_coordinates(atom_coords1, new_atom_coords)

if len(diff_indices) == 0:
    print("\033[33m [PROMPT]\033[0m The coordinates are identical.")

else:
    # Write the new structure data to a file
    output_file = "POSCAR.reference.new.vasp"
    write_poscar(output_file, lattice_vectors1, atom_count1, new_atom_coords, element_names1)
    #------------------打印新旧refer对比----------------------------
#    print("\033[36m >> The following coordinates have been adjusted based on periodic boundary conditions: \033[0m \n")
    
    line_text("Compare the reference to the new reference")
    atom_coords1 = np.array(atom_coords1)
    new_atom_coords = np.array(new_atom_coords)
    count_num=0 #计数
    for i in range(len(atom_coords1)):
        row1 = ' '.join('{:^8.4f}'.format(atom_coords1[i][j]) for j in range(len(atom_coords1[i])))
        row2 = ' '.join('{:^8.4f}'.format(new_atom_coords[i][k]) for k in range(len(new_atom_coords[i])))
        if count_num not in diff_indices:
            print(' | {:<62s}|'.format(row1))
        else:
            row_join = "{} >> {}".format(row1, row2)
            print(' | {:<62s}|'.format(row_join))
        count_num += 1
    print(" +===============================-===============================+")
    print("\033[32m [SUCCESS]\033[0m POSCAR.reference.new.vasp was written.")
#--------------------------------------------------------------------------------
