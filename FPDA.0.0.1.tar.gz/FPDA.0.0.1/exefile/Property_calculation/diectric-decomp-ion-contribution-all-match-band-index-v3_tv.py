#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.30

### Usage Commands ###
'''
First step: Prepare the OUTCAR file containing Born effective charges, irreps.yaml file and band.yaml file.
Second step: Modify the value of variable ir_labels in line 109, please replace it with the IR reducible symbol of your material.  
Third step: run the command: python diectric-decomp-ion-contribution-v2.py 
'''
import yaml
import numpy as np
import math
import os
import re
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------
#+---------------------------------输入文件检查与提示-----------------------------------+
files = os.listdir('.') # 当前目录
#files = ['OUTCAR', 'irreps.yaml', 'band.yaml']
not_found = []

if 'OUTCAR' not in files:
    not_found.append('OUTCAR')

if 'irreps.yaml' not in files:
    not_found.append('irreps.yaml')

if 'band.yaml' not in files:
    not_found.append('band.yaml')
if not_found:
    print("\033[31m [ERROR]\033[0m")
    for condition in not_found:
        print(f"    {condition} not exist!")
    print("    Prepare the OUTCAR file containing Born effective charges,\n    irreps.yaml file and band.yaml file in current dir.")    
    exit()
#-----------------------------------------------------
#获取不可约表示符号
def read_irreps(irreps_file):
    with open(irreps_file, 'r') as file:
        data = yaml.safe_load(file)
    ir_labels = [mode['ir_label'] for mode in data['normal_modes']]
    return ir_labels

irreps_file = 'irreps.yaml'
read_ir_labels = read_irreps(irreps_file)
unique_ir_labels = list(set(read_ir_labels))
line_text("All irreducible representations")
print(f" {unique_ir_labels}")
line_text('')
print(" Please enter IR-active irreducible representations\n separated by space, for example 'B1 A1 B2'")
print(" 0)  Quit")
print(" ************^-^*************")
print("➤", end='')
ir_labels_input = input()
ir_labels = list(filter(None, ir_labels_input.split(' ')))  #filter 去除空值
if ir_labels[0] == '0' and len(ir_labels) == 1:
   exit()
missing_labels = [label for label in ir_labels if label not in unique_ir_labels]
if len(missing_labels) != 0:
   print("\033[31m [ERROR]\033[0m Invalid input!")
   print(f"    Please check if {missing_labels} in irreps.yaml file!")
   exit()
    
#+------------------------------ 从OUTCAR读取波恩有效电荷 ------------------------------+
def extract_atom_num(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    atom_num = None
    for i, line in enumerate(lines):
        if "ion  position" in line:
            for next_line in lines[i + 1:]:
                if next_line.strip() == '' or not next_line.split()[0].isdigit():
                    break
                atom_num = int(next_line.split()[0])

    return atom_num


def extract_born_charges(filename, atom_num):
    with open(filename, 'r') as file:
        lines = file.readlines()

    start_line = None
    for i, line in enumerate(lines):
        if 'BORN EFFECTIVE CHARGES' in line:
            start_line = i
            break

    end_line = start_line + atom_num * 4 + 2

    born_charges = []
    ion_num = None
    charges = []
    for line in lines[start_line:end_line]:
        if "ion" in line:
            if ion_num is not None and charges:
                born_charges.append((ion_num, charges))
            ion_num = int(line.split()[1])
            charges = []
        elif line.startswith('    '):
            line_data = line.split()
            charges.extend([float(charge) for charge in line_data[1:]])

    if ion_num is not None and charges:
        born_charges.append((ion_num, charges))

    return born_charges

# Example filename and start/end lines for testing
filename = 'OUTCAR'

# Call the function to extract the number of atoms
atom_num = extract_atom_num(filename)

# Call the function to extract BORN EFFECTIVE CHARGES data
born_charges = extract_born_charges(filename, atom_num)

born_charges_tensor = []
ion_num_list = []

if born_charges:
    line_text('')
    print("\033[32m [SUCCESS]\033[0m\n    born_effective_charge.dat was written.")
    with open("born_effective_charge.dat", 'w') as file:
        for ion_num, charges in born_charges:
            ion_num_list.append(ion_num)
            file.write(f'ion {ion_num}\n')
            for i in range(0, len(charges), 3):
                born_charges_tensor.append(charges[i:i+3])
                file.write(' '.join(map(str, charges[i:i+3])) + '\n')
            file.write('\n')
else:
    print('\033[31m [ERROR]\033[0m Unable to extract BORN EFFECTIVE CHARGES data from OUTCAR!')
    
#+--------------------------------------------------------------------------------------+

#+--------------------- 从irreps.yaml读取红外激活的频率和不可约符号 --------------------+
import yaml

def find_irreps(irreps_file, ir_labels):
    with open(irreps_file, 'r') as file:
        data = yaml.safe_load(file)
    
    result = []
    for mode in data['normal_modes']:
        ir_label = mode['ir_label']
        if ir_label in ir_labels and mode['frequency'] > 0.1:  # Consider floating-point errors
            band_indices = ', '.join(str(idx) for idx in mode['band_indices'])
            frequency = mode['frequency']
            result.append({'ir_label': ir_label, 'band_indices': band_indices, 'frequency': frequency})
        
    return result
       
irreps_file = 'irreps.yaml'
#ir_labels = ['T1u']   #['B1', 'A1', 'B2']
#ir_labels = ir_labels_input.split()

matching_irreps = find_irreps(irreps_file, ir_labels)
freq_list = [irrep['frequency'] for irrep in matching_irreps]
band_indices_list = [irrep['band_indices'] for irrep in matching_irreps]
ir_label_list = [irrep['ir_label'] for irrep in matching_irreps]
               #------消除不可约符号的简并以便正确打印结果------#对于简并的情况，原先的ir_label_list这个列表只打印了一个不可约符号，这对最后打印结果调用列表的维度不一致
ir_label_list_new = []
for ir_label, band_indices in zip(ir_label_list, band_indices_list):
    if ',' in band_indices:
        # Split band_indices into individual values
        indices = band_indices.split(', ')
        for idx in indices:
            ir_label_list_new.append(ir_label)
    else:
        ir_label_list_new.append(ir_label)

               #---------------------------------------------#
'''
# Print the matching irreps information
print(f"\033[34m>> Infrared (IR-active) Irrep_label, Band_index, and Frequency:\033[0m \n")
for irreps in matching_irreps:
    ir_label = irreps['ir_label']
    band_indices = irreps['band_indices']
    frequency = irreps['frequency']
    print(f"ir_label: {ir_label:10} band_indices: {band_indices:10} frequency: {frequency} ")
'''

#+------------------------- 从band.yaml读取红外激活的本征矢实部 ------------------------+
from itertools import islice #

        #-------提取第二个’q-position:‘的行号n，仅读取前n行有用信息以提高效率-----#
def get_second_line_number(filename, keyword):
    count = 0
    with open("band.yaml", "r") as file:
        for i, line in enumerate(file, start=1):
            if keyword in line:
                count += 1
                if count == 2:
                    return i
    return None

filename = 'band.yaml'
keyword = 'q-position:'

line_number = get_second_line_number(filename, keyword)
         #--------------------------------------------------------------------------#
# Read the band.yaml file

with open("band.yaml") as f:
    lines = list(islice(f, line_number))    #

data = yaml.safe_load(''.join(lines))  #

frequencies = [entry['frequency'] for entry in data['phonon'][0]['band']]
#frequency_index = {frequency: i for i, frequency in enumerate(frequencies)}

# Create a dictionary of all frequencies and indices
frequency_index = {}
for i, frequency in enumerate(frequencies):
    if frequency in frequency_index:
        frequency_index[frequency].append(i)
    else:
        frequency_index[frequency] = [i]
        
# Read the phonon section and check the q-position
phonon = data["phonon"]
q_position = [0.0000000, 0.0000000, 0.0000000]  # Replace with the desired q-position
matched_bands = []
for band in phonon:
    if band["q-position"] == q_position:
        for index in range(len(band_indices_list)):
            for band_info in band["band"]:
                if [index + 1 for index in frequency_index.get(band_info["frequency"], [])] == [int(i) for i in band_indices_list[index].split(", ")]:
                    matched_bands.append(band_info)
        break  # Exit the loop once the desired q-position is found

if not matched_bands:
    print("\033[31m [ERROR]\033[0m No matching q-point found!!!")

IR_active_frequency = []
IR_active_eigenvector = []

with open("infrared-active-eigenvector.dat", "w") as file:
    for band in matched_bands:
        eigenvectors = band["eigenvector"]
        IR_active_frequency.append(band['frequency'])
        file.write(f"Frequency: {band['frequency']}\n")
        for i, eigenvector in enumerate(eigenvectors):
            file.write(f"Atom {i+1}: ")
            component1 = [component[0] for component in eigenvector]
            component2 = [component[1] for component in eigenvector]
            IR_active_eigenvector.append(component1)
            file.write(f"{component1} {component2}\n")
        file.write("\n")
print(f"    infrared-active-eigenvector.dat was written.")

# Read the lattice section and calculate the crystal volume
lattice = data["lattice"]
volume = np.dot(lattice[0], np.cross(lattice[1], lattice[2]))

# Read the points section and save atomic symbol and mass
points = data["points"]
symbol_list = [point['symbol'] for point in points]
mass_list = [point['mass'] for point in points]  
#+--------------------------------------------------------------------------------------+

#+--------- 下面是基于波恩有效电荷和红外激活声子本征矢计算离子贡献介电张量矩阵 ---------+
#Assign every 3 rows of the original array to one atom
born_charges_atom = [born_charges_tensor[i:i+3] for i in range(0, len(born_charges_tensor), 3)] 
#Assign every n (number of atoms) rows of the original array to one IR active frequency
eigenvector_frequency = [IR_active_eigenvector[i:i+len(mass_list)] for i in range(0, len(IR_active_eigenvector), len(mass_list))] 

mode_charge_sum = []
ion_dielectric_tensor = [] #Initialization
ion_dielectric_sum = np.zeros((3,3))
    
#units: e=1.602176634×10-19C, Å3=10-30m3, 𝜀0: 8.854187817 ×10-12 F/m, THz=1012Hz=1012s-1, 1 a.m.u.= 1.66053886×10-27 kg
unit_conv = 44224.5367151 #Unit conversion coefficient 

for mode in range(len(IR_active_frequency)):
    mode_effective_charge = []  #Initialize and empty the array
    for atom_index in range(atom_num):
        mode_effective_charge.append(np.dot(born_charges_atom[atom_index], math.sqrt(1/mass_list[atom_index])*np.array(eigenvector_frequency[mode][atom_index]).reshape(-1, 1)))
    mode_charge_sum.append(np.sum(mode_effective_charge, axis=0))
    ion_dielectric_tensor.append(np.dot(mode_charge_sum[mode], np.transpose(mode_charge_sum[mode])) / (volume * IR_active_frequency[mode] ** 2) * unit_conv)
ion_dielectric_sum = np.sum(ion_dielectric_tensor, axis=0)

'''
#Another way to sum arrays element by element
for tensor in  np.array(ion_dielectric_tensor):
    ion_dielectric_sum = np.add(ion_dielectric_sum, tensor)
'''


with open("mode-effective-charges.dat", "w") as file:
    # Write the header
    file.write("IR-freq       Z*xx             Z*yy             Z*zz\n")
    # Write the data
    for freq, charge in zip(IR_active_frequency, mode_charge_sum):
        file.write(f"{freq:6.3f}")
        file.write(f"{charge[0][0]:14.4f}   {charge[1][0]:14.4f}   {charge[2][0]:14.4f}\n")
print("    mode-effective-charges.dat was written.")        
 
print("    ion-dielectric-tensor.dat was written.") 
with open("ion-dielectric-tensor.dat", "w") as file:
    # Write the header
    line_text('Ion dielectric tensor of input representations')
   # file.write("Band-index IRrep-label IR-freq(THz)       εxx              εyy              εzz\n")
    row = "{:<10s} {:<11s} {:<12s}  {:<3s}      {:<3s}      {:<3s}".format("Band-index", "IRrep-label", "IR-freq(THz)", "εxx", "εyy", "εzz")
    print(' |{:<63s}|'.format(row))
    file.write(row+"\n")
    εxx=0
    εyy=0
    εzz=0
    # Write the data
    for band_indice, freq, tensor,irlabel in zip(band_indices_list, IR_active_frequency, ion_dielectric_tensor,ir_label_list_new):
 #       file.write(f" {band_indice:^10s}   {irlabel.ljust(3)}        {freq:6.3f}")
 #       file.write(f" {tensor[0][0]:14.4f}   {tensor[1][1]:14.4f}   {tensor[2][2]:14.4f}\n")
        row_context="{:>5s}          {:<7s} {:>8.3f}     {:>7.4f}  {:>7.4f}  {:>7.4f}".format(band_indice, irlabel.ljust(3), freq, tensor[0][0], tensor[1][1], tensor[2][2])
        print(' |{:<63s}|'.format(row_context))
        file.write(row_context+"\n")
        εxx += tensor[0][0]
        εyy += tensor[1][1]
        εzz += tensor[2][2]
#    file.write(f"-------->       sum  {εxx:14.4f}   {εyy:14.4f}   {εzz:14.4f}\n")
    row_end='{:>35s} {:>7.4f}  {:>7.4f}  {:>7.4f}  '.format("SUM:", εxx, εyy, εzz) 
    print(' |{:>63s}|'.format(row_end))
    file.write(row_end+"\n")
    line_text('')
    
'''
print("\033[36m>> The ionic part of static dielectric tensor from the contributions of all IR-active phonon modes.\033[0m \n")
for row in np.array(ion_dielectric_sum):
    for element in row:
        print("{:.14f}".format(element), end=" ")
    print()
print("\033[97m+=================================================================================================+\033[0m \n")
'''
