#!/usr/bin/env python
#from pymatgen.io.vasp import Poscar
from pymatgen.core import Lattice, Structure
from pymatgen.io.vasp import Poscar
import os
import numpy as np
import sys
import atexit
import re
##--------------
#暂未考虑周期性边界条件
#---------------

# 重置scale到新POSCAR进行运算,以解决pymatgen的scale写入新POSCAR之后为只能为一.
def reset_poscar_scale(POS,counter):
  name=["IS","FS"]
  with open(POS) as f:
   lines = f.readlines()
  oled_scale = lines[1]
  lines.pop(1)
  new_scale=1.0
  lines.insert(1, str(new_scale) + '\n')
  with open(name[counter]+"_temp.POSCAR", 'w') as f:
   f.writelines(lines)

def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------

#--------------读取当前目录文件去除隐藏文件----------------
files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
#---------------------------------------------------------------------------

##-----------------------打印当前文件价文件-------------------------------
#print(" +===============================-===============================+")
line_text("Current directory files")
max_len = 57
line_len = 0
i=-1 #计数
for file in files:
  i+=1
  if i == 0:
    print("  -", end='')  #单独为第一行打印 -
  if line_len + len(file) > max_len:
    print("\n", end='  -')
    line_len = 0  
  print(" "+file, end=', ')
  line_len += len(file) + 2
#print("\n +===============================-===============================+")
print("\n", end='')
#-------------------------------------------------------

##-------------------------------输入选项-------------------
print(" +========================= Warm Prompt =========================+")
print(" | Enter three parameters: POSCAR1 POSCAR2 Number                |")
print(" | Or use '-' for default values.                                |")
print(" |     POSCAR1    -- Default: IS                                 |")
print(" |     POSCAR2    -- Default: FS                                 |")
print(" |     Number     -- Number to insert between POS1 and POS2      |")
print(" | Example:          'POSname1 POSname2 15' '- - 6'              |")
print(" +===============================-===============================+")
print(" Enter parameters (separated by space)\n 0) quit:")
print(" ************^-^*************")
print("➤", end='')
param = input()
params = list(filter(None, param.split(' ')))  #filter 去除空值
#---------------------------------------------------

#--------------------控制默认文件名--------------
IS="IS"
FS="FS"
#---------------------------------------------

#-------------判断输入参数有效性,正确读取结构信息----------------
if params[0] == '0' and len(params) == 1:
  exit()
elif len(params) != 3:
  line_text('')
  print("\033[31m [ERROR]\033[0m Enter three parameters! Please retry.")  
  exit()
inputfile = params[0]
inputfile1 = params[1]
#判断pos1
if inputfile == '-':
   inputfile = "IS"
##判断pos2
inputfile1 = params[1]
if inputfile1 == '-':
   inputfile1 = "FS"
##判断文件是否在当前目录
if not os.path.exists(inputfile):
   line_text('')
   print("\033[31m [ERROR]\033[0m POSCAR file '"+inputfile+"' does not exist! Please retry.")
   exit()
if not os.path.exists(inputfile1):
   line_text('')
   print("\033[31m [ERROR]\033[0m POSCAR file '"+inputfile1+"' does not exist! Please retry.")
   exit()

##判断插值数num个格式    
struc_num= params[2]
try:
  num = int(struc_num)
  if not (0 < num < 100):
    line_text('')
    print("\033[31m [ERROR]\033[0m Enter an integer between 0 and 100!")
    exit()
except ValueError:
  line_text('')
  print("\033[31m [ERROR]\033[0m The input is not an integer!")  
  exit()
#-----------------------
##判断是否为POSCAR格式
def check_input(filename):
  try:
    p = Poscar.from_file(filename)
  except:
    line_text('')
    print(f"\033[31m [ERROR]\033[0m Please check {filename} file format!")
    sys.exit()
check_input(inputfile)
check_input(inputfile1)

#非正常退出及时清除temp文件
def clean_up():
  os.remove('IS_temp.POSCAR')
  os.remove('FS_temp.POSCAR')

##处理POSCAR文件
reset_poscar_scale(inputfile,0)
reset_poscar_scale(inputfile1,1)

##非正常退出及时清除temp文件
atexit.register(clean_up)
#-------------------------------------------------------------------------

# 自定义函数获取POSCAR描述信息
def get_desc_from_file(POSCAR):
    with open(POSCAR) as f:
        lines = f.readlines()
        desc = lines[0]
        scale = float(lines[1])
    return desc, scale #注释行,缩放系数

# 读取POSCAR信息
def read_poscar(POSCAR):
    p = Poscar.from_file(POSCAR)
#    coo = p.structure.cart_coords #直角坐标
    coo = [site.frac_coords for site in p.structure]
    basis = p.structure.lattice.matrix
    lattice = p.structure.lattice.abc
    elements = [site.species_string for site in p.structure]
    num_sites = len(p.structure)
    selective = p.selective_dynamics
    desc, scale = get_desc_from_file(POSCAR)
    #filetype = "POSCAR"
    natoms = p.structure.composition.element_composition
    # 获取元素符号
#    elements = poscar.site_symbols
    # 获取元素原子数目
    #atom_counts = poscar.natoms
    return coo, basis, lattice, elements, num_sites, selective, desc, scale, natoms
    # 主程序


#线性插值
def interpolate(interp_count):
  is_coo, is_basis, is_lattice, is_elements, is_num_sites, is_selective, is_desc, is_scale, is_natoms = read_poscar("IS_temp.POSCAR")
  fs_coo, fs_basis, fs_lattice, fs_elements, fs_num_sites, fs_selective, fs_desc, fs_scale, fs_natoms = read_poscar("FS_temp.POSCAR")
  IS_desc, IS_scale = get_desc_from_file(inputfile)
  FS_desc, FS_scale = get_desc_from_file(inputfile1)
  #判断化学式是否相同
  if sorted(is_elements) != sorted(fs_elements):
    line_text('')
    print("\033[31m [ERROR]\033[0m Check if two initial structures have the same formula!!")
    sys.exit()
  #提示基矢不同
  np_arr1 = np.array(is_basis)
  np_arr2 = np.array(fs_basis)
  if (np_arr1 != np_arr2).any():
    line_text('')
    print("\033[31m [NOTE]\033[0m Lattice vectors differ! I HOPE YOU KNOW WHAT YOU ARE DOING.")
  factors = [i/(interp_count+1) for i in range(interp_count+2)]
  file_names = []
  i=0
  for f in factors:
    #切换数据类型方便插值
    is_lattice = np.array(is_lattice)
    fs_lattice = np.array(fs_lattice)
    fs_coo = np.array(fs_coo)
    is_coo = np.array(is_coo)
    #插值
    t_lattice = is_lattice + f * (fs_lattice - is_lattice) #tuple
    scale = IS_scale + f * (FS_scale - IS_scale)
    basis = is_basis + f * (fs_basis - is_basis)
    coords = is_coo + f * (fs_coo - is_coo) #list
    #切回数据类型
    t_lattice = tuple(t_lattice)
    coord_list = coords.tolist()
    coords = [np.array(item) for item in coord_list]
    #写入POSCAR
    lattice = Lattice(basis, pbc=t_lattice)
    struct_interp = Structure(lattice, is_elements, coords)
    if is_selective is not None:
      struct_interp.add_site_property('selective_dynamics',is_selective) #检查selective格式，格式不对会报错
    poscar = Poscar(struct_interp)
    file_name = f"POSCAR-{i:02}"
    i += 1
    poscar.write_file(file_name)
    file_names.append(file_name)

    #----重写scale为interp_scale--------
    with open(file_name) as f:
     content = f.readlines()
    # 删除运算scale
    content.pop(1)
    # 插入正确scale
    scale = round(scale, 2)
    content.insert(1, str(scale) + '\n')
    with open(file_name, 'w') as f:
     f.writelines(content)
#    os.remove('IS_temp.POSCAR')
#    os.remove('FS_temp.POSCAR')
interpolate(num)
line_text('')
print(f"\033[32m [SUCCESS]\033[0m 00-{(num+1):02} structures generated, please check.")
