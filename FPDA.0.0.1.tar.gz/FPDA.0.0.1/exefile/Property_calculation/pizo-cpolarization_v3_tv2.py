#!/usr/bin/env python
# -*- coding: utf-8 -*

# Written by Gang Tang--2023.05.15
# Modified by Gang Tang--2023.06.01
# References: https://github.com/mzkhalid039/Polarization-Born-charges/blob/main/bcpolarization.py

### Usage Commands ###
'''
First Step: put "OUTCAR (including Born effective charge)", "POSCAR.reference" and "POSCAR.polar"files in the same directory,  

Second Step: run the command: python bcpolarization_v3.py POSCAR.reference POSCAR.polar 
'''
from pymatgen.io.vasp.inputs import UnknownPotcarWarning
import warnings
from pymatgen.io.vasp import Poscar
import numpy as np
import sys
import os
import re
warnings.filterwarnings("ignore", category=UnknownPotcarWarning)
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------

#--------------读取当前目录文件去除隐藏文件----------------
files = os.listdir('.') # 当前目录
files = [file for file in files if not file.startswith('.')]  #过滤.开头的隐藏文件。
#---------------------------------------------------------------------------

'''
##-------------------------------输入选项-------------------
line_text("\033[31mPlease Note\033[0m")
print(" Enter the refer \033[31mbefore\033[0m the polar phase!!")
print(" Put 'OUTCAR' with Born effective charge in current dir.")
line_text("Option")
print(" 1)  Read the refer and polar files by default.\n 0)  Quit")
print(" Or) Enter two structure file names (separated by space).")
#print("     - Put the refer \033[31mbefore\033[0m the polar phase!!")
#print("     - Put 'OUTCAR' with Born effective charge in current dir.")
print(" +===============================-===============================+")
'''
#---------------------------------------------------
#----------------判断OUTCAR是否存在-------------------
if 'OUTCAR' not in files:
  print("\033[31m [ERROR]\033[0m OUTCAR file not exist!\n    Put 'OUTCAR' with Born effective charge in current dir.")
  exit()
if 'POSCAR_refer' not in files:
  print("\033[31m [ERROR]\033[0m POSCAR_refer file not exist!")
  exit()
if 'relax_strained_POSCAR' not in files:
  print("\033[31m [ERROR]\033[0m relax_strained_POSCAR directory not exist!")
  exit()
#------------------------------------------------------
def read_coordinate(POSCAR):
    with open(POSCAR, 'r') as f:
        lines = f.readlines()
        #使用python库读取poscar坐标，以防 坐标后面出现 ！N   而读取不了
        p = Poscar.from_file(POSCAR)
        coo = [site.frac_coords for site in p.structure]
        atoms_coord =np.array([coord.tolist() for coord in coo]) #将数组转为列表
        # 使用列表推导式和map()函数读取晶格矢量、原子数和坐标
        lattice = np.array([list(map(float, line.split()[:3])) for line in lines[2:5]])
        atom_types = lines[5].split()
        num_atoms = list(map(int, lines[6].split()))
#        atoms_coord = np.array([list(map(float, line.split()[:3])) for line in lines[8:sum(num_atoms)+8]])
    return lattice, atom_types, num_atoms, atoms_coord
p = Poscar.from_file('POSCAR_refer')
elements = [site.species_string for site in p.structure]


def polarzition_collect(pwd):
     #读取应变结构POSCAR文件并分别获取晶格矢量、原子数和坐标
    latt0, atomtype0, atomnum0, coord0 = read_coordinate('POSCAR_refer')
    latt1, atomtype1, atomnum1, coord1 = read_coordinate('relax_strained_POSCAR/'+pwd+'/CONTCAR')

    # 构造原子类型列表
    atom_list = []
    for i, atom_type in enumerate(atomtype1):
        atom_list += [atom_type] * atomnum1[i]


    # 计算两个POSCAR文件中原子坐标的差值
    delta_pos = coord1 - coord0

    # 使用矩阵乘法计算差值坐标在latt1下的坐标
    delta_pos_C = np.matmul(delta_pos, latt1)
    # 读取OUTCAR中波恩有效电荷数据
    with open('OUTCAR') as f:
        lines = f.readlines()
        for line in lines:
            if 'volume of cell' in line:
                volume = float(line.split(':')[1].split()[0])

        start_line = 0
        for i, line in enumerate(lines):
            if 'BORN EFFECTIVE CHARGES' in line:
                start_line = i
                break
        if start_line == 0:
            print("\033[31m [ERROR]:\033[0m\n    Verify if the OUTCAR file contains BORN EFFECTIVE CHARGES!")
            print("    Or some information of the OUTCAR may be modified!")
            exit()
        end_line = start_line + sum(atomnum0)*4+2
        born = lines[start_line:end_line]

    # Extract relevant data from born and write to file
    new_born = [line.split()[1:] for line in born if line.startswith('    1') or line.startswith('    2') or line.startswith('    3')]
    new_born = np.array([[float(x), float(y), float(z)] for x, y, z in new_born])

    # 根据公式计算极化值
    #p = dipole / volume, p: μC/cm2; dipole: eÅ; volume: Å3; 1 Elementary charge [e] = 1.602176565 ×10-19 Coulomb [C].  
    Conv = 1602.176565 # Value of Conv
    polarization = [] 

    for i in range(len(delta_pos_C)):
        start_index = i * 3
        end_index = start_index + 3
        new_born_matrix = new_born[start_index:end_index, :]
        delta_pos_C_vector = delta_pos_C[i, :]
        polarization_vector = np.dot(new_born_matrix, delta_pos_C_vector) / volume*Conv
        polarization.append(polarization_vector)

    polarization_all = np.sum(polarization, axis=0) 
    #------------矩阵数据处理-----------------
    # 将列表数组连接成一个大矩阵
    concatenated_matrix = np.concatenate(polarization)

    # 将大矩阵转换为三列的矩阵
    result_matrix = np.reshape(concatenated_matrix, (-1, 3))

    # 处理矩阵，将三列拼成一个大列
    result1 = result_matrix.reshape(-1, 1, order='F')

    # 将两个POSCAR文件中原子坐标的差值写入文件 #np.savetxt('difference.dat', delta_pos, fmt='%.6f')
    with open('all_atom-position-diff.dat', 'a', encoding='utf-8') as f:
        f.write(pwd+"\n")
        for posc, atom in zip(delta_pos_C, atom_list):
            f.write(f'{posc[0]:12.6f} {posc[1]:12.6f} {posc[2]:12.6f}  {atom} (Unit: Å)\n')
        '''
        for dx, dy, dz in delta_pos:
            f.write(f"{dx:.6f} {dy:>12.6f} {dz:>12.6f}\n")
        '''
    # 将极化矢量写入文件
    with open('all_polarization.dat', 'a', encoding='utf-8') as f:
     f.write(f"{pwd:<30s}")
     f.write(f" {polarization_all[0]:>8.3f}\t{polarization_all[1]:>8.3f}\t{polarization_all[2]:>8.3f} (Unit: \N{GREEK SMALL LETTER MU}C/cm²) \n")
    return result1
#-------------------------------------------------------------
#按顺序读取目录
relax_files = os.listdir('relax_strained_POSCAR') # 当前目录
sorted_names = sorted(relax_files, key=lambda x: int(x[:2])) ## 按文件名前两位的数字大小进行排序

#--------------拼接处理后的大列列表-----------------
direction = ['x','y','z']
result_columns = []
direction_columns = []
#        -----使用嵌套循环生成重复元素的元素方向--------
for d in direction:
    direction_columns.extend([d] * len(elements))
# 复制atomtype0的所有元素3次
elements *= 3
# 转换为NumPy数组并重塑为一列矩阵
atomtype0_matrix = np.array(elements).reshape(-1, 1)
direction_matrix = np.array(direction_columns).reshape(-1, 1)
# 将atomtype0_matrix和direction_matrix按列拼接
result_columns  = np.concatenate((atomtype0_matrix, direction_matrix), axis=1)
#------------------------------------------------------------------
#新建文件
with open('all_polarization.dat', 'w', encoding='utf-8') as f:
  pass
with open('all_atom-position-diff.dat', 'w', encoding='utf-8') as f:
  pass
#循环写入信息
for name in sorted_names:
    result1 = polarzition_collect(name)
    result_columns = np.concatenate((result_columns, result1), axis=1)
# 创建结果矩阵
###-----------------------打印，写入 函数---------------------------------
def matrix_print(matrix_name, filename, width_precision='8.4', text='', title=''):  # width_precision 默认值为 '8.4'
    with open(filename, 'w') as file:
      file.write(title+'\n')
#      line_text(text)
      for i in range(len(matrix_name)):
          row_title = ' '.join('{:^2s}'.format(columns_to_insert[i][k]) for k in range(2))
          row_num = ' '.join('{:>{wp}f}'.format(matrix_name[i][j], wp=width_precision) for j in range(len(matrix_name[i])))
          row="{} {}".format(row_title,row_num)
 #         print(' |{:^63s}|'.format(row))
          file.write(row + '\n')
#    print(" +===============================-===============================+")
#    print(f"\033[32m [SUCCESS]\033[0m {filename} file was written.")

data_to_write = np.array(result_columns[:, 2:], dtype=float)
columns_to_insert = result_columns[:, :2]
matrix_print(data_to_write, "all_ion-decomp-polarvalue.dat", width_precision='12.6',title='(Unit: \N{GREEK SMALL LETTER MU}C/cm²)' )
	
line_text('')
print("\033[32m [SUCCESS]\033[0m\n    all_atom-position-diff.dat was written.\n    all_ion-decomp-polarvalue.dat was written.\n    all_polarization.dat was written.")
