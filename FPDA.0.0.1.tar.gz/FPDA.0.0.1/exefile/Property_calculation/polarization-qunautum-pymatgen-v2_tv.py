#!/usr/bin/env python

# -*- coding: utf-8 -*



# Written by Gang Tang--2023.07.03



### Usage Commands ###

'''

run the command: python polarization-qunautum-pymatgen-v1.py

'''

'''
目前只能自动处理半导体的数据，对于中间结构为金属的不能处理数据！！！
'''
# 导入必要的库

import os

import numpy as np

from pymatgen.io.vasp.outputs import Outcar

from pymatgen.core import Structure

from pymatgen.analysis.ferroelectricity.polarization import Polarization
import re
###  +=====居中打印文字=====+
def line_text(text):
  line = "+===============================================================+"
  clean_string = re.sub(r'\033\[\d+m', '', text)  #清除转义字符
  line_num=(len(line)-len(clean_string)-2-2)//2
  prompt = "=" * line_num
  if len(clean_string) == 0:
    print(" +===============================-===============================+")
    pass
  elif len(clean_string) % 2 == 1: #奇数居中打印
    print(" +{} {} {}+".format(prompt, text, prompt))
    pass
  else:                   #偶数补足=
    print(" +{} {} {}=+".format(prompt, text, prompt))
#-----------------end------------------
line_text('Warm Prompt')
print(" | The ferroelectric calculation folders for all structures need |")
print(" | to be gathered in the 'neb_calculate' folder, otherwise the   |")
print(" | data cannot be processed!                                     |")
print(" | \033[31mNote\033[0m:                                                         |")
print(" |      Fill 0-9 file names with 0 to make two digits!           |")
print(" | Like:                                                         |")
print(" |                    ╭ 00.vasp/{INCAR, POSCAR, ·····, OUTCAR}   |")
print(" |      neb_calculate/│ 01.vasp/{INCAR, POSCAR, ·····, OUTCAR}   |")
print(" |                    ╰ 02.vasp/{INCAR, POSCAR, ·····, OUTCAR}   |")
line_text('')
# 从 OUTCAR 和 POSCAR 文件中读取数据

#outcar = Outcar("OUTCAR")

#structure = Structure.from_file("POSCAR")

#判断当前目录是否存在neb_caculate文件夹
files1 = os.listdir('.') # 当前目录
if 'neb_calculate' not in files1:
    print("\033[31m [ERROR]\033[0m neb_calculate folder not exist!")
    exit()

#为了方便处理数据，要将所有结构的铁电计算文件夹集中到neb_caculate中
files2 = os.listdir('neb_calculate')
#----#

outcars = [] 

structures = []

for i in files2:

    outcar = Outcar(f"neb_calculate/{i}/OUTCAR") #print(f"{i:02d}") 打印2位数字 00 01 

    poscar = Structure.from_file(f"neb_calculate/{i}/POSCAR")

    outcars.append(outcar)

    structures.append(poscar)



# 使用 from_outcars_and_structures() 方法创建 Polarization 对象

pol = Polarization.from_outcars_and_structures(outcars, structures)

#pol = Polarization.from_outcars_and_structures(outcars, structures, calc_ionic_from_zval=True)

#打印、写入函数
def matrix_print(matrix_num, matrix_name, matrix_name1, filename, width_precision='8.4', text='', file_title=''):  # width_precision 默认值为 '8.4'
    with open(filename, 'w') as file:
      file.write( file_title+'\n')
      line_text(text)
      if matrix_num == 2:
        for i in range(len(matrix_name)):
            row = ' '.join('{:^{wp}f}'.format(matrix_name[i][j], wp=width_precision) for j in range(len(matrix_name[i])))
            row1 = ' '.join('{:^{wp}f}'.format(matrix_name1[i][k], wp=width_precision) for k in range(len(matrix_name1[i])))
            row_tot= "{}|{}".format(row, row1)
            print(' |{:^63s}|'.format(row_tot))
            file.write(row_tot + '\n')
      elif matrix_num == 1:
        for i in range(len(matrix_name)):
            row = ' '.join('{:^{wp}f}'.format(matrix_name[i][j], wp=width_precision) for j in range(len(matrix_name[i])))
            print(' |{:^63s}|'.format(row))
            file.write(row + '\n')
    print(" +===============================-===============================+")
    print(f"\033[32m [SUCCESS]\033[0m {filename} file was written.")
#
pelecs_and_pions = pol.get_pelecs_and_pions()
matrix_print(2, pelecs_and_pions[0],  pelecs_and_pions[1],"ferr-ele-ion-contr.dat",text ='Electronic and ionic contributions',file_title='Electronic contributions:        Ionic contributions:', width_precision='9.3' )

#
lattice_quanta = pol.get_lattice_quanta()
matrix_print(1,lattice_quanta,'',"lattice_quanta.dat", text='Lattice quanta',file_title='polarization quantum along x-axis, y-axis, z-axis: (Unit: \N{GREEK SMALL LETTER MU}C/cm²)',width_precision='9.3')

#
same_branch_data = pol.get_same_branch_polarization_data()
matrix_print(1,same_branch_data,'',"Same-branch-polarization.dat", text='Same branch data',file_title='Corrected same branch polarization values along x-axis, y-axis, z-axis:(Unit: \N{GREEK SMALL LETTER MU}C/cm²)', width_precision='9.3')

polarization_change = pol.get_polarization_change()

print(" Polarization change:", polarization_change)



polarization_change_norm = pol.get_polarization_change_norm()

print(" Polarization change norm:", polarization_change_norm)

with open('Same-branch-polarization.dat', 'a', encoding='utf-8') as file:

    file.write("\nCorrected final polarization values along x-axis, y-axis, z-axis:(Unit: \N{GREEK SMALL LETTER MU}C/cm²)\n")

    for row in polarization_change:

        line = '      '.join([f"{value:.3f}" for value in row])

        file.write(line + '\n')


max_spline_jumps = pol.max_spline_jumps()

print(" Max spline jumps:", max_spline_jumps)

line_text("")
'''
same_branch_splines = pol.same_branch_splines()

print(" Same branch splines:", same_branch_splines)
'''


'''

# 写入 lattice_quanta 数据

with open('lattice_quanta.dat', 'w', encoding='utf-8') as file:

    file.write("polarization quantum along x-axis, y-axis, z-axis: (Unit: \N{GREEK SMALL LETTER MU}C/cm²) \n")

    for row in lattice_quanta:

        line = '      '.join([f"{value:.5f}" for value in row])

        file.write(line + '\n')



# 写入 Electronic and ionic contributions 数据

electronic_ionic_data = np.concatenate(pelecs_and_pions, axis=1)

with open('Electronic-ionic-contributions.dat', 'w') as file:

    # Writing electronic contributions

    file.write("Electronic contributions:\n")

    for row in electronic_ionic_data:

        line = '      '.join([f"{value:.5f}" for value in row[:3]])  # 前三列数据

        file.write(line + '\n')



    file.write('\n')  # 写入空行

    # Writing ionic contributions

    file.write("Ionic contributions:\n")

    for row in electronic_ionic_data:

        line = '      '.join([f"{value:.5f}" for value in row[3:]])  # 后三列数据

        file.write(line + '\n')



# 写入 Same branch polarization data 数据

with open('Same-branch-polarization-data.dat', 'w', encoding='utf-8') as file:

    file.write("Corrected final polarization values along x-axis, y-axis, z-axis:(Unit: \N{GREEK SMALL LETTER MU}C/cm²)\n")

    for row in polarization_change:

        line = '      '.join([f"{value:.3f}" for value in row])

        file.write(line + '\n')

        

    file.write('\n')

    file.write("Corrected same branch polarization values along x-axis, y-axis, z-axis:(Unit: \N{GREEK SMALL LETTER MU}C/cm²)\n")

    for row in same_branch_data:

        line = '      '.join([f"{value:.5f}" for value in row])

        file.write(line + '\n')
'''
