 #!/bin/bash
current_directory=$(basename "$(pwd)") 
#echo " "
#echo -e "\e[1;33m please put 'tvasp.tar.gz' in the main directory(~) \n \e[0m"
#echo -e "\e[1;33m Otherwise you cannot use the 'learn' command well \n \e[0m"
 
 
# user=`echo $USER`
 
 #if [ "$user"x != "root"x ];then
echo -n " Do you want to install FPDA in your main directory(~)? (yes or no)"
echo -e "\n 0) Quit"
echo -e "\n ************^-^*************"
echo -n "➤"

read guess
if [[ "$guess" = "0" ]];then
   exit 0
fi

if [ "$guess"x == "yes"x ];then
   path=`pwd`
   echo "                             " 
   echo "########### FPDA #############
export fpdapath=$path
export PATH=$path/exefile/src:\$PATH"  >> $HOME/.bashrc  
   source ~/.bashrc
   echo -e "\e[1;33m You have install it successfully\n \e[0m"
   echo -e " Enter the 'fpda' command to bring up the function directory" 
elif  [ "$guess"x == "no"x ];then
   echo " Enter your desired installation path"
   echo " 0) Quit"
   echo  " ************^-^*************"
   echo -n "➤"
   read  road
   if [[ "$road" = "0" ]];then
      exit 0
   fi
   path=$road"/$current_directory"     
   echo "########### FPDA #############
export fpdapath=$path
export PATH=$path/exefile/src:\$PATH"  >> $HOME/.bashrc
   mv ../$current_directory $road   
   source $HOME/.bashrc
   echo -e "\e[1;33m You have install it successfully\n \e[0m"
   echo -e " Enter the 'fpda' command to bring up the function directory"
fi
echo " PATH:$path"
source $HOME/.bashrc
#echo " PATH to ~/.bashrc :$path"
sh $path/exefile/src/welcome
